package com.capgemini.seleniumtesting.webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Gmail {
	static {
		System.setProperty("webdriver.chrome.driver", "/testing__workspace/seleniumtesting/src/main/resources/chromedriver.exe");
	}
	public static void main(String[] args) {
		//open the browser
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Enter the URL
		driver.get("https://www.gmail.com");
		//Enter the valid username
		driver.findElement(By.id("identifierId")).sendKeys("dikshat703@gmail.com");
		//Click on next
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		//Enter the valid password
		driver.findElement(By.name("password")).sendKeys("dikshat9701");
	}
}//End of class
