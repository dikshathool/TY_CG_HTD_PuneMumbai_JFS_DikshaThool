package com.capgemmini.simpleSelenium;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.simpleSelenium.Calculator;

public class TestCalculator {
	@Test
	public void addTest() {
		Calculator cal = new Calculator();
		int a = 50;
		int b = 60;
		int expected = 110;
		int actual = cal.add(a, b);
		
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void subTest() {
		Calculator cal = new Calculator();
		int a = 70;
		int b = 20;
		int expected = 50;
		int actual = cal.sub(a, b);
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void mulTest() {
		Calculator cal = new Calculator();
		int a = 70;
		int b = 20;
		int expected = 1400;
		int actual = cal.mul(a, b);
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void divTest() {
		Calculator cal = new Calculator();
		int a = 60;
		int b = 20;
		int expected = 3;
		int actual = cal.div(a, b);
		Assert.assertEquals(expected, actual);
	}
}
