package com.capgemmini.simpleSelenium;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

public class TestOne {
	static {
		System.setProperty("webdriver.chrome.driver", "/testing__workspace/seleniumtesting/src/main/resources/chromedriver.exe");	
	}
	@Test
	public void testOne() throws InterruptedException {
		//Open the browser
		ChromeDriver driver = new ChromeDriver();
		//Loading the application after entering URL
		driver.get("https://demo.actitime.com/");
		//To send value use sendKey
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.name("pwd")).sendKeys("manager");
		driver.findElement(By.xpath("//div[text()='Login ']")).click();
		Thread.sleep(5000);//Time given after login
		
		String expected = "actiTIME - Enter Time-Track";
		String actual = driver.getTitle();
		
		Assert.assertEquals(actual, expected);
		Thread.sleep(2000);//Time given before closing tag
		driver.close();
		
		
	}
}
