package com.capgemini.junit.junit_jupitor;

public class Test {
	public static void main(String[] args) {
		Student s = new Student("Divya", 67.9,'F');
		Student s2 = new Student("Simran", 35.9,'F');
		
		School sc = new School();
		
		//sc.registerStudent(null);
		
		Student regStu = sc.registerStudent(s);
		Student regStu2 = sc.registerStudent(s2);
		
		System.out.println("ID is "+regStu.getId());
		System.out.println("Name is "+regStu.getName());
		System.out.println("---------------------------------");
		
		System.out.println("ID is "+regStu2.getId());
		System.out.println("Name is "+regStu2.getName());
		System.out.println("---------------------------------");
	}
}
