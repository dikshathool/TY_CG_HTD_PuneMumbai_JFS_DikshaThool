package com.capgemini.junit.junit_jupitor;

public class Sum {
	public int add(int a, int b) {
		return a+b;
	}//End of Sum()
	
	public int add(int a, int b, int c) {
		return a+b+c;
	}
}//End of class
