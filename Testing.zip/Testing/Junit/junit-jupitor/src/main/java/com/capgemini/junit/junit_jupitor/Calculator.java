package com.capgemini.junit.junit_jupitor;

public class Calculator {
	public int add(int a, int b) {
		return a+b;
	}//End of add()
	public int subtract(int a, int b) {
		return a-b;
	}//End of subtract()
	public int multiply(int a, int b) {
		return a*b;
	}//End of multiply()
	public int div(int a, int b) {
		return a/b;
	}//end of div()
	public int mod(int a, int b) {
		return a%b;
	}//End of mod()
	
	
}//End of class
