package com.capgemini.junit.junit_jupitor;

public class Factorial {
	public int fact(int a) {
		int fact = 1;
		for(int i=1; i<=a; i++) {
			fact = fact *i;
		}
		return fact;
	}//End of fact()
}//End of class
