package com.capgemini.junit.junit_jupitor;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class FactTest {
	private Factorial factorial = null;
	
	@BeforeEach
	public void createObject() {
		factorial = new Factorial();
	}
	@Test
	public void testFactForNumber() {
		int i = factorial.fact(5);
		assertEquals(120, i);
	}//End of factTest()
	
	@Test
	public void testFactForZero() {
		int i = factorial.fact(0);
		assertEquals(1, i);
	}
	
	@Test
	public void testFactForNegative() {
		int i = factorial.fact(-6);
		assertEquals(1, i);
	}
}//End of class
