package com.capgemini.junit.junit_jupitor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CalculatorTest {
	private Calculator calculator = null;
	//Objects gets created before each case execution
	@BeforeEach
	public void createObject() {
		calculator = new Calculator();
	}
	@Test
	public void addTest() {
		int i = calculator.add(25, 20);
		assertEquals(45, i);
	}//End of addTest()
	@Test
	public void addnegativeTest() {
		int i = calculator.add(-25, 20);
		assertEquals(-5, i);
	}//End of addTest()
	@Test
	public void subtractTest() {
		int i = calculator.subtract(25, 20);
		assertEquals(5, i);
	}//End of subtractTest()
	@Test
	public void multiplyTest() {
		int i = calculator.multiply(25, 20);
		assertEquals(500, i);
	}//end of multiplyTest()
	@Test
	public void divTest() {
		int i = calculator.div(25, 5);
		assertEquals(5, i);
	}//End of divTest()
	@Test
	public void testDivByZero() {
		assertThrows(ArithmeticException.class, ()->calculator.div(10, 0));
	}//End of testDivByZero()
	@Test
	public void modTest() {
		int i = calculator.mod(25, 2);
		assertEquals(1, i);
	}//End of modTest()
}//End of class
