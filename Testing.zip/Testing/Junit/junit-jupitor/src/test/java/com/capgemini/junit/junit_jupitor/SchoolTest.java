package com.capgemini.junit.junit_jupitor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SchoolTest {
	private School school;
	//Create object before each test case
	@BeforeEach
	public void createObject() {
		school = new School();
	}
	
	@Test
	public void testRegisterStudent() {
		Student student = new Student();
		Student stu = school.registerStudent(student);
		assertEquals(1, stu.getId());
	}//End of testRegisterStudent()
	@Test
	public void testRegisterStudentForNull() {
		assertThrows(NullPointerException.class, ()->school.registerStudent(null));
	}//End of testRegisterStudentForNull() 
}
