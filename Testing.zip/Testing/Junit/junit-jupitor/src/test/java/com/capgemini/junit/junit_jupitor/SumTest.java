package com.capgemini.junit.junit_jupitor;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SumTest {
	Sum s = new Sum();
	@Test
	public void addTest() {
		// Two values
		int i = s.add(10, 16);
		assertEquals(26, i);// To compare expected and actual value
	}// End of addTest()
	
	@Test
	public void addTest1() {
		// Three values
		int r = s.add(10, 2, 50);
		assertEquals(62, r);
	}
}// End of class
