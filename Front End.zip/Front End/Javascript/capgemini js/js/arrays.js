// var x = [12344, 'xyz', true, {name: 'Shahrukh Khan'}];
// //console.log(x[3]);

// for(var i=0; i< x.length;i++){
//     console.log(x[i]);
// }

var colors = ['yellow', 'green', 'white', 'red'];
console.log(colors);
colors.pop();
console.log(colors);
colors.push('violet', 'blue');
console.log(colors);
colors.shift();
console.log(colors);
colors.unshift('grey', 'black');
console.log(colors);

colors.splice(2, 2);
console.log(colors);
colors.splice(3, 1, 'indigo', 'orange', 'indian black');
console.log(colors);

colors.forEach(function(value, index, array){
    console.log(value, index, array);
});

var myArray=[1,2,3,4,5,6,4,3,3,6,7,8,9];
var newArray=myArray.filter(function(value){
    return value>3;
});
console.log(newArray);
//filter method for unique value
var filteredArray = myArray.filter(function(value,index,array){
    return array.indexOf(value)===index;
});
console.log(filteredArray);

if(123 == '123'){
    console.log('true');
}else{
    console.log('false');
}
if(123 === '123'){
    console.log('true');
}else{
    console.log('false');
}

//for in loop
// for(var x of myArray){
//     console.log(x);
// }

for(var index in colors){
    console.log("The value is "+colors[index] + " and the index is "+ index);
}

var movie = {
    name: 'Kick',
    actor: 'Salman Khan',
    actress: 'Jaqline' ,
    director: 'Sajid Nadiawala'
};
console.log(movie['name']);
for(var key in movie){
    console.log(key +" : "+ movie[key]);//to access value of object use [] otherwise it will show undefined
}

function test(){
    var x=100;
    let y='xyz';
    console.log(x);
}


// setTimeout(function(){
//     console.log('10 seconds done');
// },10000);

// // var i=1;
// // setInterval(function(){
// //     console.log(i);
// //     i++;
// // },2);



// //callback concept
// function test(callback){
//     console.log('test function started');
//     callback();
//     console.log('test function ended');
// }
// test(function(){
//     console.log('callback function is being executed');
// });

