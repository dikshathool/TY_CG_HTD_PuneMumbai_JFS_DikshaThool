//anonymous function with expression 
var x=function(){
    console.log('Hello from anonymous function');
}
//calling a function
x();

//naming function
function add(a, b){
    console.log(a+b);
}
//calling a naming function
add(12,13);

//immediately invoke function expression
(function(x, y){
    console.log('iife is being executed');
    console.log('Result is ',x*y);
}) (1234, 453);

//understanding return keyword
function division(a, b){
    return a/b;
}
console.log(division(25,5));


