//fat arrow function 
let add = (a,b) => {
    console.log('The sum is: ', a+b);
}
add(12,23);

//fat arrow function with one argument
let printAge = age =>{
    console.log('The age is: ', age);
}
printAge(12345);

//fat arrow function with only return statement
let product=(a,b) =>a*b;
    console.log('The product is: ', product(123,123));