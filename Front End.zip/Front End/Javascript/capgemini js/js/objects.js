//literal way of object creation
var student = {
    name: 'Diksha Thool',
    age: 22,
    degree: 'BE',
    phoneNumber: 3456892718 
};

console.log(student.name);
console.log(student);

student.phoneNumber=5678923467;
console.log(student.phoneNumber);

student.selectedCompany = 'Capgemini';
console.log(student);

//using object constructor
var laptop = new Object();
laptop.brand= 'Dell';
laptop.ram= '8GB';
laptop.processor ='core i5';
laptop.price = 49999;

console.log(laptop);

console.log(Object.keys(laptop).length+
);

