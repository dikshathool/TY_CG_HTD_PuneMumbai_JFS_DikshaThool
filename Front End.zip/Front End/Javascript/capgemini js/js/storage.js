localStorage.getItem('name','ashfg');
console.log(localStorage.getItem('name'));
console.log(localStorage.length);
localStorage.clear();
console.log(localStorage.length);
