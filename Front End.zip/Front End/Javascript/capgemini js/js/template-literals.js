var myString= `The Lamborghini Aventador is a mid-engine sports car produced by the Italian automotive .....
 Lago, Carlos (30 January 2012). "2012 Lamborghini Aventador LP 700-4 European Spec First Test". Motor Trend. Retrieved 4 February 2016.
 The Ferrari 458 Italia (Type F142) is a mid-engine sports car produced by the Italian automobile ..... The car debuted at the 2012 24 Hours of Daytona. 
 AimAutosport.com is the first team to win with the new 458 Italia Grand-Am spec. On Sept.`

 console.log(myString);

 //embedded expression
 var name = 'Diksha';
 var role = 'CR';
 var batch = 'Mumbai';
 console.log(`I am ${name} and I am the ${role} of ${batch} batch`);

 console.log(`The sum of 1234 and 4321 is ${1234+4321}`);