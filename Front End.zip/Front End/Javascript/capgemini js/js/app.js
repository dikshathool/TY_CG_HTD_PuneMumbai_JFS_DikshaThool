// prompt('please write your name');
var myName = 6789654;
myName='Diksha'
console.log(typeof myName);

var areYouGood = true;