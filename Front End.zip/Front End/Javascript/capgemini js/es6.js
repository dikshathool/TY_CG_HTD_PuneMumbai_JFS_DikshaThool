let person = {
    name : 'Anushka',
    age : 30
};

let student = {
    ...person,
    id : 1234,
    percentage : 55.55
}
console.log(student);

// let mumbaiCRS= ['Akash','Aishwarya'];
// let noidaCRS= ['Kartik', 'Monali'];
// let bangaloreCRS= ['Yasmin','Shahid'];
// let bhuvaneshwaeCRS= ['Kaushik','Manisha'];
// let CRS = [
//     ...mumbaiCRS,
//     ...noidaCRS,
//     ...bangaloreCRS,
//     ...bhuvaneshwaeCRS,
//     'subrat'
// ]
// console.log(CRS);

// let [name1,name2,name3,...restValues]=CRS;
// console.log(name1);
// console.log(name2);
// console.log(name3);
// console.log(restValues);

// let mumbaiCRS ={
//     name1 : 'Akash',
//     name2 : 'Aishwarya'
// };
// let noidaCRS ={
//     name1 : 'Kartik',
//     name2 : 'Monali'
// };
// let bangaloreCRS ={
//     name1 : 'Yasmin',
//     name2 : 'Shahid'
// };
// let bhuvaneshwarCRS ={
//     name1 : 'Kaushik',
//     name2 : 'Manisha'
// };
// let CRS = {
//     ...mumbaiCRS, ...noidaCRS, ...bangaloreCRS, ...bhuvaneshwaeCRS
// }
// console.log(CRS);

//there is no method to reverse string
let myString ='Capgemini trainees are really intelligent';
console.log(myString.indexOf('are'));
console.log(myString.includes('train'));
let reversedString = myString.split('').reverse().join('');
console.log(reversedString);

console.log(myString.charAt(2));
console.log(myString.charCodeAt(1));//ASCII value of character