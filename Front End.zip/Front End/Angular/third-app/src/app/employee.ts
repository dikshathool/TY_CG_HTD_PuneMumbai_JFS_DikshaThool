export class Employee {
    constructor(
        public empId: string,
        public name: string,
        public email: string,
        public phone: number,
        public status: string,
        public pk?: string
    ){}
}