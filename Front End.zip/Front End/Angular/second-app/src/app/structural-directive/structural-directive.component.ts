import { Component, OnInit } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-structural-directive',
  templateUrl: './structural-directive.component.html',
  styleUrls: ['./structural-directive.component.css']
})
export class StructuralDirectiveComponent implements OnInit {
  flag = false;
  person = 'Kaushik';

  students : Student[]= [
    {
      id: 1231,
      name: 'Diksha Thool',
      age: 22,
      degree: 'BE'
    }, {
      id: 1232,
      name: 'Saddam',
      age: 27,
      degree: 'BTECH'
    }, {
      id: 1233,
      name: 'Raghav Patil',
      age: 30,
      degree: 'MTECH'
    }, {
      id: 1234,
      name: 'Raima',
      age: 25,
      degree: 'BTECH'
    } ,{
      id: 1235,
      name: 'Gaurav',
      age: 45,
      degree: 'BE'
    }
  ]

  constructor() { 
    setTimeout(() =>{
      this.flag = true;
    },2000);
  }

  deleteStudent(student: Student) {
    const index = this.students.indexOf(student);
    this.students.splice(index, 1);
  }

  ngOnInit() {
  }

}
