export class Product {
    constructor(
        public name: string,
        public imageURL: string,
        public price: number,
        public details: string
    ){}
}