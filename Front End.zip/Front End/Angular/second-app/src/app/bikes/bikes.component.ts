import { Component, OnInit } from '@angular/core';
import { Bike } from '../bike';

@Component({
  selector: 'app-bikes',
  templateUrl: './bikes.component.html',
  styleUrls: ['./bikes.component.css']
})
export class BikesComponent implements OnInit {
  
  bikes: Bike[] = [
    {
      brand: 'Royal Enfield',
      imgURL: 'https://cdn.pixabay.com/photo/2018/07/01/11/42/royal-enfield-3509231__340.jpg',
      model: 'classic 350',
      price: 160000,
      specs: `The 346cc, single cylinder, 4-stroke, twin-spark motor generates a maximum output of 20.08PS at 5250rpm and 28Nm of torque at 4000rpm. The power is transferred to the rear wheel via a five-speed gearbox. The Classic has a fuel capacity of 13.5 litres and weighs in at 192kg.`
    },{
      brand: 'Jawa',
      imgURL: 'https://cdn.pixabay.com/photo/2017/10/29/14/13/motorcycle-2899797__340.jpg',
      model: '293cc single-cylinder',
      price: 2000000,
      specs: `The motorcycle comes with a 293cc single-cylinder DOHC liquid-cooled engine that complies with BSVI emission norms. It generates 27PS of power and 28Nm of torque and is mated to a six-speed gearbox. The motorcycle comes with a double cradle frame.` 
    },{
      brand: 'TVS',
      imgURL: 'https://cdn.pixabay.com/photo/2017/12/29/05/58/sport-3046819__340.jpg',
      model: 'TVS Apache RTR 160',
      price: 500000,
      specs:`TVS Motors has launched the Apache RTR 160 2V with single-channel ABS. The rear drum variant is priced at Rs 85,510 while the rear disc version retails for Rs 88,339 (both prices ex-showroom, Delhi). Draped in white with red stripes and blue with white stripes, the liveries are elegantly done. There’s a premium TVS logo on the fuel tank, and the engine cowl sports TVS Racing stickers as well. Even the black alloy wheels get TVS Racing rim stickers for a sporty appeal.`
    },{
      brand: 'KTM',
      imgURL: 'https://cdn.pixabay.com/photo/2019/04/19/10/29/motorcycle-4139052__340.jpg',
      model: 'KTM 390 Duke',
      price: 400000,
      specs:`The KTM 390 Duke is powered by a 373.2 cc air-cooled engine which produces of power. It has a fuel tank of 13.4 L and a . The KTM 390 Duke starts at Rs 2.48 Lakh Rs (ex-showroom, Delhi). It is available in one variants.`
    },{
      brand: 'Bajaj',
      imgURL: 'https://cdn.pixabay.com/photo/2016/07/25/06/16/bajaj-pulsur-1539973__340.jpg',
      model: 'Bajaj Pulsar 150 ABS',
      price: 80000,
      specs:`Pulsar 150 is a widely known name in commuter sport motorcycle segment of India. It first appeared 17 years ago when the Pulsar brand name was just started. Pulsar 150 carries an updated 149cc engine, producing 14 HP at 8000 rpm and 13.4 Nm at 6000 rpm. Pulsar 150 claims a top speed of 115 kph while weighs fairly high at 144 kg. The comfortable riding position and excellent 45-50 kmpl of mileage make it a nice choice against Honda CB Unicorn.`
    }
  ];

  selectedBike: Bike = this.bikes[0];
  constructor() { }

  selectBike(bike){
    this.selectedBike = bike;
  }
  ngOnInit() {
  }

}
