import { Component, OnInit } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products : Product[] =[
   {
    name: 'Macbook Air',
    imageURL: 'https://cdn.pixabay.com/photo/2015/01/26/10/23/office-612532__340.jpg',
    price: 59999,
    details: 'Very Good Laptop'
   } ,{
      name: 'Smart Phone',
      imageURL: 'https://cdn.pixabay.com/photo/2015/12/13/16/02/ios-1091302__340.jpg',
      price: 30000,
      details: 'Very Good Smart Phone'
     } ,{
      name: 'Cat',
      imageURL: 'https://cdn.pixabay.com/photo/2014/04/13/20/49/cat-323262__340.jpg',
      price: 99999,
      details: 'Very Good Cat'
     },{
      name: 'Digital Watch',
      imageURL: 'https://cdn.pixabay.com/photo/2015/07/02/10/29/smartwatch-828786__340.jpg',
      price: 49000,
      details: 'Very Good Digital Watch'
     },{
      name: 'Smart TV',
      imageURL: 'https://image.shutterstock.com/image-photo/back-view-couple-watching-smart-260nw-714316759.jpg',
      price: 90999,
      details: 'Very Good Smart TV'
     }
   
  ]
  constructor() { }

  ngOnInit() {
  }

}
