import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent implements OnInit {
    inputData;
    flag= true;
    name='Diksha';
    imgURL='https://cdn.pixabay.com/photo/2019/10/27/21/13/flowers-4582844__340.png';

  // constructor() { 
  //   setTimeout(() =>{
  //     this.flag = true;
  //   },5000);
    constructor() { 
      setInterval(() =>{
        this.flag =! this.flag;
      },1000);
   }
   eventOccured(input) {
    console.log(input.value);
    console.log('key up event occured');
  }

  ngOnInit() {
  }

}
