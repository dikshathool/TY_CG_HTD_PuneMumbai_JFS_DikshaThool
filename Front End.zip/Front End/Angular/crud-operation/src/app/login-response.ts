export class LoginResponse  {
    constructor(
       public email: string,
       public expiresIn: string,
       public idToken: string,
       public kind: string,
       public localId: string,
       public refreshToken: string,
       public registered: boolean
    ) {}
}
