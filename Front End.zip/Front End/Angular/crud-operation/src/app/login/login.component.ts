import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  error = null;
  constructor(public auth: AuthService, private router: Router) { }

  loginUser(loginForm: NgForm) {
    this.error = null;
    this.auth.login(loginForm.value).subscribe( Response => {
      console.log(Response);
      loginForm.reset();
      if (Response.registered) {
        const user = JSON.stringify(Response);
        localStorage.setItem('token', user);
        this.router.navigateByUrl('/products');
      }
    }, err => {
      console.log(err);
      this.error = err.error.error.message;
    });
  }

  ngOnInit() {
  }

}
