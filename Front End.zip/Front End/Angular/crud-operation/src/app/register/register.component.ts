import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  error = null;
  constructor(public auth: AuthService) { }

  registerUser(registerForm: NgForm) {
    this.error = null;
    this.auth.register(registerForm.value).subscribe( Response => {
      console.log(Response);
      registerForm.reset();
    }, err => {
      console.log(err);
      this.error = err.error.error.message;
    });
  }
  ngOnInit() {
  }

}
