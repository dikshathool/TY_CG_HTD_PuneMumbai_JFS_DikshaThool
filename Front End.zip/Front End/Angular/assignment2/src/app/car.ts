export class Car {
    constructor(
        public brand: string,
        public imgURL: string,
        public model: string,
        public specs: string
    ){}
}