export class Bike {
    constructor(
        public brand: string,
        public imgURL: string,
        public model: string,
        public specs: string
    ){}
}