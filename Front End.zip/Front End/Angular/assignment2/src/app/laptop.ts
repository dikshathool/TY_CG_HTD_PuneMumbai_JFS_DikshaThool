export class Laptop {
    constructor(
        public brand: string,
        public imgURL: string,
        public price: string,
        public specs: string
    ){}
}