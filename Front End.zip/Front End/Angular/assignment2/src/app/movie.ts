export class Movie{
    constructor(
        public name: string,
        public imgURL: string,
        public rating: string,
        public specs: string
    ){}
}