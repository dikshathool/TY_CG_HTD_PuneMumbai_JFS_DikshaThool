export class Mobile {
    constructor(
        public brand: string,
        public imgURL: string,
        public price: string,
        public specs: string
    ){}
}