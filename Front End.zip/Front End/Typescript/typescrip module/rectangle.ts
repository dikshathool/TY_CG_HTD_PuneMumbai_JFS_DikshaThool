export class Rectangle {
    areaOfCircle(arg0: number): any {
        throw new Error("Method not implemented.");
    }
    perimeter(l:number, b:number): number{
        return 2*(l+b);

    }
    areaOfRectangle(l: number, b: number): number{
        return l*b;
    }
}