package com.capgemini.empwebapp.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/redirect")
public class RedirectServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//we can redirect to external or internal resource
		String url = "http://www.google.com"; //external resource
		//String url1 = "./currentDate"; //internal resource
		//there is no actual content so dont use setContentType
		//redirect to above url
		resp.sendRedirect(url);
	}//End of doget

}//end of class
