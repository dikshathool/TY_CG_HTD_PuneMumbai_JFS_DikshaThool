package com.capgemin.functionalInterface;

import java.util.function.Predicate;

public class TestA {
	public static void main(String[] args) {
		Predicate<Integer> p = (i)->{
			if(i%2 == 0) {
				return true;
			} else {
				return false;
			}
		};
		
		boolean a = p.test(15);
		System.out.println("Result is: "+a);
	}//End of main()
}//End of class
