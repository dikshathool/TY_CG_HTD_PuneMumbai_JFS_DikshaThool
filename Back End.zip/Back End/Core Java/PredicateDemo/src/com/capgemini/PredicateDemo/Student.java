package com.capgemini.PredicateDemo;

public class Student {
	int id;
	String name;
	double percentage;
	char gender;
	public Student(){
		
	}
	public Student(int id, String name, double percentage,char gender) {
		this.id = id;
		this.name = name;
		this.percentage = percentage;
		this.gender=gender;
	}

	
}
