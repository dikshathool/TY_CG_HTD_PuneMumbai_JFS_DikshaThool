package com.capgemini.PredicateDemo;

import java.util.function.Predicate;

public class Demo {
	public static void main(String[] args) {
		//Predicate<Integer> p -> i%2 ==0;
		
		Predicate<Integer> p=i -> {
		if(i%2 == 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	};
	
	boolean res=p.test(15);
	System.out.println("Result is: "+res);
	
}
}
