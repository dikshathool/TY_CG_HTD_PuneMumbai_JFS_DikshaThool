package com.capgemini.PredicateDemo;

import java.util.function.Function;

public class FunctTest {
	public static void main(String[] args) {
		Function<Integer, Integer> f=i ->i*i;
		
		int ans=f.apply(5);
		System.out.println("Result is: "+ans);
	}

}
