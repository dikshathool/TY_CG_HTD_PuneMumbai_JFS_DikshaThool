package com.capgemini.PredicateDemo;

import java.util.function.Predicate;

public class Student1 {
	public static void main(String[] args) {
		Predicate<Student> p= k -> {
			if(k.percentage >= 35)
			{
				return true;
			}
			else
			{
				return false;
			}
		};
		
		Student a=new Student(1,"Pinki",'F');
		boolean res=p.test(a);
		System.out.println("Result is: "+res);

	}

	

}
