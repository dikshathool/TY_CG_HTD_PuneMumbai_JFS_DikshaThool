package com.capgemini.PredicateDemo;

import java.util.function.Function;
//when we want to give object and return object
//In this code, only id value we are passing
public class Test {

	public static void main(String[] args) {
		Function<Integer, Student> f=i ->{
			Student s=new Student();
			s.id=i;
			return s;
		};

		Student s=f.apply(10);
		System.out.println("Name is: "+s.name);
		System.out.println("ID is: "+s.id);
		System.out.println("Percentage is: "+s.percentage);
	}

}
