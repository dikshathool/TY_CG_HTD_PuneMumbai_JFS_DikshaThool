package com.capg.corejava.cfs;

public class Ifelse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
