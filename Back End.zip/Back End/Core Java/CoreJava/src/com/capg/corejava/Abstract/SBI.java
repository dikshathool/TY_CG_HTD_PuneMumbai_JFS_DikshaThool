package com.capg.corejava.Abstract;

public class SBI implements ATM {

	@Override
	public void validateCard() {
		System.out.println("..........Connecting to SBI DB");
		System.out.println("I am validating the SBI DB");
		
	}

	@Override
	public void getInfo() {
		System.out.println("..........Connecting to SBI DB");
		System.out.println("I am getting SBI account holder info");
		
	}

}
