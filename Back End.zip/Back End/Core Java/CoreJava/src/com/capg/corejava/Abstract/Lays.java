package com.capg.corejava.Abstract;

public class Lays implements Chips1 {

	@Override
	public void open() {
		System.out.println("I am opening Lays");
	}

	@Override
	public void eat() {
		System.out.println("I am eating Lays");
	}
		
}
