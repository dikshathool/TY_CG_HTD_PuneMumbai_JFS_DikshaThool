package com.capg.corejava.Abstract;

public class Bingo implements Chips1 {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("I am opening Bingo");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("I am eating Bingo");

	}

}
