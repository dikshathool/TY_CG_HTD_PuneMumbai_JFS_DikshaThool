package com.capg.corejava.basics;

public class Test {

	public static void main(String[] args) {
		/*
		 * Marker q=new Pen();//we cannot do direct downcasting,
		 * first we have to perform upcasting otherwise it will 
		 * show ClassCastException
		 */
		Pen p=new Marker();//upcasting
		Marker i=(Marker)p;//downcasting
		
		i.cost=100;
		System.out.println("Cost of pen="+i.cost);
		i.write();
		i.size=2.4;
		System.out.println("Size of marker="+i.size);
		i.color();
	}

}
