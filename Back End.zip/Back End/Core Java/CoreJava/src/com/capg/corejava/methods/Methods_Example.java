package com.capg.corejava.methods;

public class Methods_Example {
	int y=10;

	public static void main(String[] args) {
		print();
		int i=areaOfSquare(2);
		System.out.println("Area of Square= "+i);
		System.out.println(areaOfSquare(6));
		
		/*
		 * Methods_Example me=new Methods_Example(); 
		 * int area = me.areaOfRec(2,5);  
		 */
		 //using above method we can call many methods using object variable 'me'
		int area= new Methods_Example().areaOfRec(2,5);
		System.out.println(area); 
		System.out.println(new Methods_Example().areaOfRec(8,2));//it will reduced number of line

	}
	public static void print() {
		System.out.println("print() method");
	}
	public static int areaOfSquare(int side) 
	{
		return(side*side);
	}
	public int areaOfRec(int length,int width) 
	{
		return(length*width);
	}

}
