package com.capg.corejava.basics;

public class Marker extends Pen {
	double size;
	void color()
	{
		System.out.println("marker method");
	}

}
