package com.capg.corejava.loops;

public class Do_While_Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		do {
			System.out.println("i= "+i);
			i++;
		}while(i<=10);
		System.out.println("Code outside do-while loop");
		
		/*
		 * do { 
		 * System.out.println("i= "+i); i++; 
		 * 
		 * }while(true);
		 * System.out.println("Code outside do-while loop");
		 */

	}

}
