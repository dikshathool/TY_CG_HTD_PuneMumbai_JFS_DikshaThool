package com.capg.corejava.methods;

public class Car {
	
		String name;
		String color;
		double price;
		
		public Car(String name, String color, double price) 
		{
			
			this.name = name;
			this.color = color;
			this.price = price;
		}
		@Override
		public String toString() {
			return "Car [name=" + name + ", color=" + color + ", price=" + price + "]";
		}
		public Car() {
			//no argument constructor created by programmer
		/*
		 * It is different from defualt constructor, but only similarity is that they
		 * both does not have any return type
		 */
		}
		
		public Car(String name) {
			this.name = name;
		}
		
		public Car(double price) {
			this.price = price;
		}
		public Car(String name, double price) {
		
		}
		public Car(double price,String name) {
			
		}
	/*
	 * we can write same number of arguments with same data type 
	 * but the order should be different
	 */
		
		
		
		
		
		

}

