package com.capg.corejava.inheritance;

public class Car {
	void move()
	{
		System.out.println("I am a move() method");
	}

}
