package com.capg.corejava.methods;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car car1=new Car("Mustang GT", "Yellow", 478954.9856);
		print(car1);
		System.out.println(car1);

	}
	public static Car print(Car car)
	{
		return car;
	}

}
