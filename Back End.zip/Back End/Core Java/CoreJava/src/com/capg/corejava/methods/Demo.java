package com.capg.corejava.methods;

public class Demo {
	static Methods_Example me = new Methods_Example();

	public static void main(String[] args) {
		//Methods_Example me = new Methods_Example();
		Methods_Example me1 = new Methods_Example();
		System.out.println(me);
		System.out.println(me1);
		System.out.println(Methods_Example.areaOfSquare(6));
		System.out.println(me.areaOfRec(6,7));
		System.out.println(me1.areaOfRec(6,7));
        int r=me.y;//non-static variable from Methods_Example
        System.out.println(r);
	}

}
