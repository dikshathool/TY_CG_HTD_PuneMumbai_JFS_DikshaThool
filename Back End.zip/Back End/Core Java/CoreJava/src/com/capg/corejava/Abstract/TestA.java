package com.capg.corejava.Abstract;

public class TestA {

	public static void main(String[] args) {
		Machine m=new Machine();
		
		HDFC h=new HDFC();
		
		ICICI i=new ICICI();
		
		SBI s=new SBI();
		
		m.slot(s);//Input given by ATM card i.e input from user side
		/* here we have taken only one slot because at a time we 
		 * can only one input */

	}

}
