package com.capg.corejava.Abstract;

public class Kurkure implements Chips1 {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("I am opening Kurkure");

	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("I am eating Kurkure");

	}

}
