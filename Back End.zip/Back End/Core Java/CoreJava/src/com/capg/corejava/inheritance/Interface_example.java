package com.capg.corejava.inheritance;

public interface Interface_example {
	public void display();
	public void show();
	/*
	 * public static void print() 
	 * { 
	 * we can have normal method inside interface 
	 * }
	 */

}
