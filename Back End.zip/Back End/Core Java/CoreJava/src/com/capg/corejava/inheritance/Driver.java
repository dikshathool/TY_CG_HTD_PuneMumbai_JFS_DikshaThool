package com.capg.corejava.inheritance;

public class Driver {
	void receive(Car c)
	{
		c.move();
	}

}
