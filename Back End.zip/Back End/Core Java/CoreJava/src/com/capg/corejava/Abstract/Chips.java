package com.capg.corejava.Abstract;

public class Chips {
	void open();
	void eat();
}
