package com.capg.corejava.interfaces;

public class ExampleImpl implements Example1 {
	
	public static void main(String []args)
	{
		Example1 obj=new ExampleImpl();
		obj.print();
		obj.display();
		obj.printNum();
	}

	/*//@Override
	 *  public static void show() {
	 * System.out.println("static method of ExampleImpl"); }
	 */
	@Override
	public void display()
	{
		System.out.println("Implemented Display Method of interface");
	}
	@Override
	public void print()
	{
		System.out.println("Implements print method of ExampleImpl");
	}

	@Override
	public void printNum() {
		System.out.println("1234567");
		
	}

}
