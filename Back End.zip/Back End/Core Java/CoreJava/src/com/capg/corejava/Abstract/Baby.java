package com.capg.corejava.Abstract;

public class Baby {
	void receive(Chips c) {
		c.open();
		c.eat();
	}

}
