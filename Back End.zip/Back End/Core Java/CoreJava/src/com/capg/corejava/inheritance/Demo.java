package com.capg.corejava.inheritance;

public abstract class Demo {
	public abstract void print();
	//if abstract method present then class should be abstract
	//we can write normal method inside abstract class
} 
