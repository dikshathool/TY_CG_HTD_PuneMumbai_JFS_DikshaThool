package com.capg.corejava.Abstract;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lays r=new Lays();
		Kurkure k=new Kurkure();
		Baby b= new Baby();
		b.receive(k);

	}

}
