package com.capg.corejava.basics;

import java.util.Scanner;

public class scanner {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in)) //try resource: compiler directly close the scanner
		{
			System.out.println("Enter the age: ");
			int age=sc.nextInt();
			System.out.println("Age is: "+age);
		}
		/*
		 * Scanner sc=new Scanner(System.in); 
		 * int age=sc.nextInt();
		 * System.out.println("Age is: "+age); 
		 * sc.close();
		 */
	}

}
