package com.capg.corejava.Abstract;

public interface Chips1 {
	void open();
	void eat();

}
