package com.capg.corejava.loops;

public class ForLoopsExample {
	public static void main(String[] args)
	{
		int i=10;
			if(i%2==0)
			{
				for(int j=1;j<=4;j++)
				{
					System.out.println(i/j);
					i++;
				}
			}
			else
			{
				System.out.println("i is odd");
			}
		
		System.out.println("code outside for loop");
	}

}
