package com.capg.corejava.loops;

public class While_Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=5;
		while(i<=10)
		{
			System.out.println(i);
		}
		System.out.println("Code outside while loop");
		
		/*
		 * while(true) 
		 * { 
		 *      System.out.println(i); i++; 
		 * }
		 * System.out.println("Code outside while loop");
		 */
	}

}
