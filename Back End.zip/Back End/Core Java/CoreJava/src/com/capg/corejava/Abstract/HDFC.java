package com.capg.corejava.Abstract;

public class HDFC implements ATM {

	@Override
	public void validateCard() {
		System.out.println("...........Connecting to HDFC DB");
		System.out.println("I am validating the HDFC bank");
	}

	@Override
	public void getInfo() {
		System.out.println("..........Connecting to HDFC DB");
		System.out.println("I am getting HDFC account holder info");
		
		
	}

}
