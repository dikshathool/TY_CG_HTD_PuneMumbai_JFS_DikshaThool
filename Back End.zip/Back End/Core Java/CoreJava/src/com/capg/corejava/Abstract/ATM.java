package com.capg.corejava.Abstract;

public interface ATM {
	/*This method will be called when user insert the card;
	 * This method will have card number and pin;
	 * validate this card and return true if the card is valid or 
	 * else return false
	 * boolean validateCard(long CardNumber, int pinNumber)
	 */
	void validateCard();
	void getInfo();

}
//It is an interface between ATM machine and user provided respective Bank
