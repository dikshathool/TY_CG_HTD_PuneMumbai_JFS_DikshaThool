package com.capg.corejava.basics;

public class Pen {
	int cost;
	void write()
	{
		System.out.println("Pen method");
	}

}
