package com.capg.corejava.Abstract;

public class ICICI implements ATM {

	@Override
	public void validateCard() {
		System.out.println("..........Connecting to ICICI DB");
		System.out.println("I am validating the ICICI DB");
		
		
	}

	@Override
	public void getInfo() {
		System.out.println("..........Connecting to ICICI DB");
		System.out.println("I am getting ICICI account holder info");
		
		
	}
	

}
