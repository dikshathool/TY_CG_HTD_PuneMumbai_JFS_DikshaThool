package com.capg.corejava.Abstract;

public class Machine {
	//here we will get input from TestA class
	void slot(ATM a)
	{
		a.validateCard();
		a.getInfo();
	}
	//ATM machine internal functions
	//it will called the functions written in ATM based on user input

}
