package com.capg.corejava.basics;

public class TypeCasting {

	public static void main(String[] args) {
		//implicit type casting
		int a=5;
		double b=a;
		System.out.println("b is"+b);
		
		//explicit type casting
		double x=2.9;
		int t=(int)x;
		System.out.println("t is"+t);

	}

}
