package com.capgemini.stringexp.one;

public interface print {
	default void print() {
		
	}
	final static void dis()
}
