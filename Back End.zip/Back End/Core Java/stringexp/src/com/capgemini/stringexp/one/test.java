package com.capgemini.stringexp.one;

public class test {

	public static void main(String[] args) {
		String a ="Theju";//create in string pool
		String b ="Dinesh";
		a="divya";
		String k="Dinesh";//id contain in k is same as b id
		String p=new String("divya");//create in heap area
		String r=new String("divya");
		String m="divya";
		
		System.out.println("a: "+a);
		System.out.println("b: "+b);
		System.out.println("k: "+k);
		
		boolean res= a==p;//compare address of objects store in a and p
		System.out.println("Result"+res);
		
		boolean res1=a.equals(p);//compare contents store in a and p

	}

}
