package com.capgemini.stringexp.one;

public class testA {

	public static void main(String[] args) {
		String k="90";
		String p="50";
		String m= "2.42";
		System.out.println(k+p);
		
		int i=Integer.parseInt(k);
		int j=Integer.parseInt(p);
		double k=Double.parseDouble(m);
		
		System.out.println(i+j);
		System.out.println(m);
	}

}
