package com.capgemini.stringexp.one;

public class Example {

	public static void main(String[] args) {
		String s="Diksha";
		String a="dikSha";
		System.out.println("Length is = "+s.length());
		
		System.out.println("Strings are = "+s.equals(a));
		System.out.println("EqualsIgnoreCase = "+s.equalsIgnoreCase(a));
		System.out.println("toUpperCase = "+a.toUpperCase());
		System.out.println("toLowerCase = "+s.toLowerCase());
	}

}
