package com.capg.exception.custom;

public class Test {
	public static void main(String[] args) {
		Ammount a= new Ammount();
		try
		{
			a.check(30000);
			System.out.println("Checked");
		}
		catch(InvalidLimitException h)
		{
			System.out.println(h.getMessage());
		}
	}

}
