package com.capg.exception.custom;

public class TestInvalid {

	public static void main(String[] args) {
		Validator v=new Validator();
		try
		{
			v.varify(15);
			System.out.println("Welcom to pub");
		}
		catch(InvalidAgeException in)
		{
			System.out.println(in.getMessage());
		}
	}

}
