package com.capg.exception.custom;

public class Validator {
	void varify(int age)
	{
		if(age<18)
		{
			throw new InvalidAgeException();
		}
	}

}
