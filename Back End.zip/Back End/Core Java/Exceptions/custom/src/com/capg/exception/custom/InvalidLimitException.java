package com.capg.exception.custom;

public class InvalidLimitException extends Exception{ //checked exception
	private String message="Day limit is only 40000";
	
	@Override
	public String getMessage() {
		return message;
	}
	

}
