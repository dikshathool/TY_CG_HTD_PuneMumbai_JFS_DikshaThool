package com.capg.exception.custom;

public class InvalidAgeException extends RuntimeException{ //unchecked exception
	private String message="Invalid age to proceed";
	public String getMessage()
	{
		return message;
	}

}
