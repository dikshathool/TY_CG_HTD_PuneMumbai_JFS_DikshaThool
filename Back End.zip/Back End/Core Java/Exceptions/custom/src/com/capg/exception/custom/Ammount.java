package com.capg.exception.custom;

public class Ammount {
	void check(int val) throws InvalidLimitException
	{
		if(val > 40000)
		{
			throw new InvalidLimitException();
		}
	}

}
//whenerver the message throwing checked exception, then throw is necessary