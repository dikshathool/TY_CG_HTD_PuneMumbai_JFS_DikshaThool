package com.capg.exceptionhandle.example;

public class arith_exp {

	public static void main(String[] args) {
		System.out.println("Main method started");
		try
		{
			System.out.println(10/2);
			System.out.println(10/0);
			
		}
		catch(ArithmeticException e)
		{
			System.out.println("Do not divide by zero");
		}
		System.out.println("Main method ended");

	}

}
