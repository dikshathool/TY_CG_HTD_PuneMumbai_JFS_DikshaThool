package com.capg.exceptionhandle.example;

public class array_exp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main method started");
		int[] a=new int[3];
		try
		{
			System.out.println(a[2]);
			System.out.println(a[7]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Dont cross array boundary");
		}
		System.out.println("Main method ended");
	}

}
