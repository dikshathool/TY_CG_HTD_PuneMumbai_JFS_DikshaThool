package com.capg.exceptionhandle.example;

import java.io.File;
import java.io.IOException;

public class Test1 {

	public static void main(String[] args) {
		System.out.println("Main started");
		File f=new File("Diksha.txt");
		try
		{
			f.createNewFile();
			System.out.println("file created");
		}
		catch(IOException e)
		{
			System.out.println("Sorry not able to create the file");
		}
		System.out.println("Main ended");
	}

}
