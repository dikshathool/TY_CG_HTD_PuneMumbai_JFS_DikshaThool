package com.capg.exceptionhandle.example;

public class exception2 {
	public static void main(String[] args) {
		System.out.println("Main method started");
		String s=null;
		int[] a=new int[3];
		try
		{
			System.out.println(s.length());
			System.out.println(a[9]);
			System.out.println(10/0);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Dont cross array Boundary");
		}
		catch(ArithmeticException r)
		{
			System.out.println("Dont divide by zero");
		}
		catch(NullPointerException k)
		{
			System.out.println("Dont deal with null");
		}
		catch(Exception t)
		{
			System.out.println("Something wrong");
		}
		System.out.println("Main method ended");

	}
	//a try block can have multiple catch blocks
	//if exception occurs then statements after exception will not get executed
	//if there are multiple exception in try block, then only first exception will get executed
	//AIO ctrl+space (ArrayIndexOutOfBoundsException)
	//AE ctrl+space(ArithmeticException)
	//general catch block should be the last catch block
}
