package com.capg.exceptionhandle.example;

public class TestAgeExcep {

	public static void main(String[] args) {
		Validator v=new Validator();
		try
		{
			v.verify(15);
			System.out.println("Welcome to pub");
		}
		catch(InvalidAgeException in)
		{
			System.err.println(in.getMessage());
		}

	}

}
