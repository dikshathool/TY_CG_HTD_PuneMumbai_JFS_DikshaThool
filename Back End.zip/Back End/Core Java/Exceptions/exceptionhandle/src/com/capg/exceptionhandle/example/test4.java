package com.capg.exceptionhandle.example;

import java.io.IOException;

public class test4 {
	public static void main(String[] args) throws IOException, ClassNotFoundException{
		Bottle b=new Bottle();

		b.open();
	}

}
