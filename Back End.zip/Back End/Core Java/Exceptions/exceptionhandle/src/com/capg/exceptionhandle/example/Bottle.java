package com.capg.exceptionhandle.example;

import java.io.File;
import java.io.IOException;

public class Bottle {
	void open() throws IOException, ClassNotFoundException{
		File f=new File("Diksha.txt");
		f.createNewFile();
		
		Class.forName("com.capg.exceptionhandle.example.Bottle");
	}


}
