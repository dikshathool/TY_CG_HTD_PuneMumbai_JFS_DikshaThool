package com.capg.exceptionhandle.example;

public class Paytm {
	void book()
	{
		System.out.println("Book started");
		IRCTC i=new IRCTC();
		try 
		{
			i.confirm();
		}
		catch(ArithmeticException c)
		{
			System.out.println("Exception caught at book");
		}
		System.out.println("Book ended");
	}

}
