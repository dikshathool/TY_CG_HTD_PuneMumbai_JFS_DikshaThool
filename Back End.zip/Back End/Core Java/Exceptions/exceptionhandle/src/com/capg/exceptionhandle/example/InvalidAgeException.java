package com.capg.exceptionhandle.example;

public class InvalidAgeException extends RuntimeException {
	private String message= "Invalid age to proceed";

	/*
	 * public InvalidAgeException(String message) { 
	 * this.message =message; }
	 */
	public InvalidAgeException()
	{
		
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}

}
