package com.capg.exceptionhandle.example;

public class BMS {

	public static void main(String[] args) {
		System.out.println("Main method started");
		PVR p=new PVR();
		try
		{
			p.confirm();
		}
		catch(ArithmeticException g)
		{
			System.out.println("Exception caught at confirm BMS");
			
		}
		System.out.println("Main method ended");
		

	}

}
