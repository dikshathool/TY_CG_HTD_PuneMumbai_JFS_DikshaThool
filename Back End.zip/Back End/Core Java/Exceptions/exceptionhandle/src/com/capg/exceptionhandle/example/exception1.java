package com.capg.exceptionhandle.example;

public class exception1 {
	public static void main(String[] args) {
		System.out.println("Main method started");
		try
		{
			System.out.println(10/2);
			System.out.println("Hi");
			System.out.println(10/0);
			System.out.println("Keep smiling");
		}
		catch(ArithmeticException e)
		{
			System.out.println("Dont divide by zero");
		}
		System.out.println("Main method ended");
	}
}
