package com.capg.exceptionhandle.example;

public class PVR {
	void confirm()
	{
		System.out.println("Print started");
		try
		{
			System.out.println(10/0);
		}
		catch(ArithmeticException l)
		{
			System.out.println("Exception caught at confirm PVR");
			throw l;
		}
		finally
		{
			System.out.println("Print ended");
		}
	}
}
//any statements written after the throw statement will not get executed
	//