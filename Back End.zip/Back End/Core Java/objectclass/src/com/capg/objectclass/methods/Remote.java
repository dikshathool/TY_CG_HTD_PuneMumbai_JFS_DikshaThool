package com.capg.objectclass.methods;

public class Remote {

}
