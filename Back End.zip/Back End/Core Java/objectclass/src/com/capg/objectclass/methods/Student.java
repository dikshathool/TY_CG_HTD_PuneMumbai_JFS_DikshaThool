package com.capg.objectclass.methods;

public class Student {
	String name;
	int id;
	double Percentage;
	public Student(String name, int id, double percentage) {
		this.name = name;
		this.id = id;
		Percentage = percentage;
	}
	
	public String toString()
	{
		return "Name: "+name+", ID: "+id+", Percentage: "+Percentage;
	}
	/*
	 * public String toString() { return
	 * "ID: "+id+", name: "+name+", Percentage: "+Percentage; }
	 */
	

}
