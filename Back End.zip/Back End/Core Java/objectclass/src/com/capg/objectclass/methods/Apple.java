package com.capg.objectclass.methods;

public class Apple {
	void eat();
	{
		
	}
	

}
