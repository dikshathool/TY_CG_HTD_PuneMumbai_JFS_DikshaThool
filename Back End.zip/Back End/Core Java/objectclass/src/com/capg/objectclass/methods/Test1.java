package com.capg.objectclass.methods;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cow c= new Cow();
		c.id=1;
		c.name="Ganga";
		c.height=50;
		
		Cow d= new Cow();
		d.id=2;
		d.name="Tunga";
		d.height=30;
		
		Cow e= new Cow();
		e.id=1;
		e.name="Ganga";
		e.height=50;
		
		boolean res=c.equals(e);
		System.out.println(res);

	}

}
