package com.capg.objectclass.methods;

public class emp {
	int id;
	String name;
	double sal;
	char gender;
	public emp(int id, String name, double sal, char gender) {
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "emp [id=" + id + ", name=" + name + ", sal=" + sal + ", gender=" + gender + "]";
	}
	
	
}
