package com.capg.objectclass.methods;

public class test2 {

	public static void main(String[] args) {
		Remote r=new Remote(1,"LG-Remote");
		System.out.println("Id is "+r.id);
		System.out.println("Name is "+r.name);

	}

}
