package com.capg.objectclass.methods;

public class Test {

	public static void main(String[] args) {
		Student s= new Student("Diksha", 3, 87.27);
		System.out.println(s);
		System.out.println(s.toString());
		
		emp e= new emp(3, "Diksha", 45000, 'F');
		System.out.println(e);

	}

}
