package com.capg.objectclass.methods;

public class Cow {
	int id;
	String name;
	int height;
	public boolean equals(Object ref)
	{
		/* downcasting */
		Cow r=(Cow) ref;//converting parent class object ref into child class object Cow
		if(this.id==r.id)
		{
			if(this.name.equals(r.name))
			{
				if(this.height==r.height)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
				
			}
		}
		else
		{
			return false;
		}
	}

}
