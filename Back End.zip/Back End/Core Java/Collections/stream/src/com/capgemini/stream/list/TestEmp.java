package com.capgemini.stream.list;

import java.util.Comparator;
import java.util.TreeSet;

public class TestEmp {
	public static void main(String[] args) {
		Comparator<Employee> comp=(e1,e2)-> {
			if(e1.height > e2.height){
				return 1;
			}else if(e1.height < e2.height) {
				return -1;
			}else {
				return 0;
			}
		};
		Comparator<Employee> comp1=(e1,e2)-> { 
			if(e1.id > e2.id){
				return 1;
			}else if(e1.id < e2.id) {
				return -1;
			}else {
				return 0;
			}
		};
		Comparator<Employee> comp2=(e1,e2)-> e1.name.compareTo(e2.name);
		
		TreeSet<Employee> ts=new TreeSet<Employee>(comp2);
		
		Employee e1=new Employee(1,"Priya",5.6);
		Employee e2=new Employee(4,"Anil",4.2);
		Employee e3=new Employee(3,"Raju",5.1);
		Employee e4=new Employee(2,"Geetha",3.5);
		
		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		ts.add(e4);
		
		for(Employee r:ts)
		{
			System.out.println("Id is: "+r.id);
			System.out.println("Name is: "+r.name);
			System.out.println("Height is: "+r.height);
			System.out.println("--------------------------");
		}
		
		
	}

}
