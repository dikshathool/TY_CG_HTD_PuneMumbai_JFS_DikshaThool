package com.capgemini.stream.list;

public class Employee {
	int id;
	String name;
	double height;
	public Employee(int id, String name, double height) {
		this.id = id;
		this.name = name;
		this.height = height;
	} 

	
}
