package com.capgemini.StudentProject;

import java.util.LinkedList;

public class array2 {

	public static void main(String[] args) {
		LinkedList<Double> al=new LinkedList<Double>();
		al.add(3.6);
		al.add(2.4);
		al.add(4.7);
		al.add(1.6);
		System.out.println("Before------->"+al);
		Double res1=al.peekLast();
		Double res2=al.peekFirst();
		Double res3=al.peek();
		System.out.println("peek object is: "+res1);
		System.out.println("peek object is: "+res2);
		System.out.println("peek object is: "+res3);
		
		System.out.println("After-------->"+al);
	}

}
