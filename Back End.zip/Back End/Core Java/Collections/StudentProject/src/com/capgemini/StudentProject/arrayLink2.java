package com.capgemini.StudentProject;

import java.util.ArrayList;
import java.util.Collections;

public class arrayLink2 {
	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		
		al.add('z');
		al.add('E');
		al.add('K');
		al.add('J');
		System.out.println("Before----->"+al);
		Collections.shuffle(al);
		System.out.println("After------>"+al);
		
		
	}

}
