package com.capgemini.StudentProject;

import java.util.ArrayList;
import java.util.Scanner;

public class MyStudentApp {
	
	int id;
	String name;
	double percentage;
	
	ArrayList al=new ArrayList();
	Scanner sc=new Scanner(System.in);
	 void addStudent()
	{
		System.out.println("Enter Student name: ");
		name=sc.next();
		System.out.println("Enter Student id: ");
		id=sc.nextInt();
		System.out.println("Enter Student percentage: ");
		percentage=sc.nextDouble();
	}
	void displayStudent()
	{
		System.out.println("Name is: "+name);
		System.out.println("Id is: "+id);
		System.out.println("Percentage is: "+percentage);
	}

}
