package com.capgemini.StudentProject;

import java.util.ArrayList;

public class StudTest {

	public static void main(String[] args) {
		ArrayList<Student> al= new ArrayList<Student>();
		Student s1=new Student(1,"Divya",98.02);
		Student s2=new Student(2,"Bhagya",55.40);
		Student s3=new Student(3,"Riya",67.45);
		Student s4=new Student(4,"Jaya",91.67);
		
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		
		Helper h=new Helper();
		//h.display(al);
		//h.onlyPass(al);
		h.distinction(al);

	}

}
