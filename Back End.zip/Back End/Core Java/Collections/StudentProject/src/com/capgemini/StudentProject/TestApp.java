package com.capgemini.StudentProject;

import java.util.Scanner;

public class TestApp {

	public static void main(String[] args) {
		MyStudentApp m=new MyStudentApp();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter the option: \n 1:Add Student \n 2:Display Student \n 3:Exit");
			int opt=sc.nextInt();
			switch(opt)
			{
				case 1: m.addStudent();
				break;
			
				case 2: m.displayStudent();
				break;
				
				case 3: System.exit(0);
				break;
				
				default:
					System.out.println("Invalid input");
			}
		}
	}

}
