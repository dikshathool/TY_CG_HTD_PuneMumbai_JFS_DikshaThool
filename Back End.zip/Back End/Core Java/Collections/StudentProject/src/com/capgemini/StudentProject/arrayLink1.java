package com.capgemini.StudentProject;

import java.util.Collections;
import java.util.LinkedList;

public class arrayLink1 {

	public static void main(String[] args) {
		LinkedList<Double> al=new LinkedList<Double>();
		al.add(3.6);
		al.add(2.4);
		al.add(4.7);
		al.add(1.6);
		System.out.println("Before------->"+al);
		Collections.sort(al);
		System.out.println("After-------->"+al);
		
		for(int i=0;i<al.size();i++)
		{
			Double r=al.get(i);
			System.out.println(r);
		}
	}

}
