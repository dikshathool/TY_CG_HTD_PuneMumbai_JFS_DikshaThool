package com.capgemini.Sorting;

public class Employee1 implements Comparable<Employee1>{
	int id;
	String ename;
	int salary;
	public Employee1(int id, String ename, int salary) {
		this.id = id;
		this.ename = ename;
		this.salary = salary;
	}
	
	//we have to override compareTo method otherwise it will throw exception
	@Override
	public int compareTo(Employee1 e) {
		Integer k=this.id;
		Integer p=e.id;
		return k.compareTo(p);
	}
	
	
	
	

}
