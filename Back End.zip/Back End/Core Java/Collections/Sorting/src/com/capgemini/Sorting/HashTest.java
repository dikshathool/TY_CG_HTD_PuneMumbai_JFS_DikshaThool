package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;

public class HashTest {

	public static void main(String[] args) {
		HashSet hs=new HashSet();
		hs.add(15);
		hs.add('A');
		hs.add(2.4);
		hs.add("Deepa");
		hs.add('A');
		hs.add(2.4);
		hs.add('A');
		hs.add(null);
		hs.add(null);//we can add one null and it does not print repeated values
		
		System.out.println("******Using for-each*********");
		for(Object r:hs)
		{
			System.out.println(r);
		}
		
	}

}
