package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;

public class TestEmp {
	public static void main(String[] args) {
		HashSet<Employee> hs=new HashSet<Employee>();
		Employee e1=new Employee(1,"Diksha",45000);
		Employee e2=new Employee(2,"Jaya",30000);
		Employee e3=new Employee(3,"Rekha",56000);
		Employee e4=new Employee(4,"Sushama",43000);
		Employee e5=new Employee(2,"Jaya",30000);
		
		hs.add(e1);
		hs.add(e2);
		hs.add(e3);
		hs.add(e4);
		hs.add(e5);
	
		System.out.println("******Using iterator*********");
		Iterator<Employee> it=hs.iterator();
		while(it.hasNext())
		{
			Employee r=it.next();
			System.out.println("ID is: "+r.id);
			System.out.println("Name is: "+r.ename);
			System.out.println("Salary is: "+r.salary);
			System.out.println("------------------------");
		}
		
	}
}
