package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkSetTest1 {
	public static void main(String[] args) {
		LinkedHashSet<Double> hs=new LinkedHashSet<Double>();
		hs.add(89.23);
		hs.add(55.75);
		hs.add(67.23);
		hs.add(45.76);
		
		System.out.println("******Using for-each*********");
		for(Double r:hs)
		{
			System.out.println(r);
		}
		System.out.println("******Using iterator*********");
		Iterator<Double> it=hs.iterator();
		while(it.hasNext())
		{
			Double r=it.next();
			System.out.println(r);
		}
	}
}
