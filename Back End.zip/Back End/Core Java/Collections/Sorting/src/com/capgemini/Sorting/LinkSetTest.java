package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkSetTest {

	public static void main(String[] args) {
		LinkedHashSet hs=new LinkedHashSet();
		hs.add(15);
		hs.add('A');
		hs.add(2.4);
		hs.add("Deepa");
		hs.add(null);//It takes null values
		
		System.out.println("******Using for-each*********");
		for(Object r:hs)
		{
			System.out.println(r);
		}
		System.out.println("******Using iterator*********");
		Iterator it=hs.iterator();
		while(it.hasNext())
		{
			Object r=it.next();
			System.out.println(r);
		}

	}

}
