package com.capgemini.Sorting;

import java.util.Iterator;
import java.util.TreeSet;
//Employee1 test
public class Test1 {
	public static void main(String[] args) {
		TreeSet<String> t=new TreeSet<String>();
		t.add("Jaya");
		t.add("Rekha");
		t.add("Hema");
		t.add("Sushama");
		
		Iterator<String> it=t.iterator();
		while(it.hasNext())
		{
			String r=it.next();
			System.out.println(r);
		}
	}

}
