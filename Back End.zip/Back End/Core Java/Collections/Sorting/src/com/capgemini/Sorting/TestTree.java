package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

//TreeSet gives only sorted output,can have Comparable type of object
public class TestTree {

	public static void main(String[] args) {
		TreeSet ts=new TreeSet();
		ts.add(15);
		ts.add(9);
		ts.add(2);
		ts.add(10);
		ts.add(null);//Tree set cannot load a null value
		System.out.println("******Using for-each*********");
		for(Object r:ts)
		{
			System.out.println(r);
		}
	
		
	}

}
