package com.capgemini.Sorting;

import java.util.HashSet;
import java.util.Iterator;

public class SetString {

	public static void main(String[] args) {
		HashSet<String> hs=new HashSet<String>();
		hs.add("Jaya");
		hs.add("Rekha");
		hs.add("Sushama");
		hs.add("Deepa");
		
		System.out.println("******Using for-each*********");
		for(String r:hs)
		{
			System.out.println(r);
		}
		System.out.println("******Using iterator*********");
		Iterator<String> it=hs.iterator();
		while(it.hasNext())
		{
			String r=it.next();
			System.out.println(r);
		}
		

	}

}
