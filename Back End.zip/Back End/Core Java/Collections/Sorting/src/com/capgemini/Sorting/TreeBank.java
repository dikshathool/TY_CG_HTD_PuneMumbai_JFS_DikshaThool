package com.capgemini.Sorting;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeBank {
	public static void main(String[] args) {
		ById comp=new ById();
		ByName comp1=new ByName();
		ByMicr comp2=new ByMicr();
		
		TreeSet<Bank> ts=new TreeSet<Bank>(comp2);
		Bank b1=new Bank(21, "SBI Bangalore", 223344l);
		Bank b2=new Bank(22,"HDFC Bangalore",445566l);
		Bank b3=new Bank(23,"Axis Bangalore",112233l);
		Bank b4=new Bank(24,"ICICI Bangalore",334411l);
		
		ts.add(b1);
		ts.add(b2);
		ts.add(b3);
		ts.add(b4);
		
		Iterator<Bank> it=ts.iterator();
		while(it.hasNext())
		{
			Bank r=it.next();
			System.out.println("Pin number is: "+r.pin);
			System.out.println("Name is: "+r.name);
			System.out.println("MICR code is: "+r.micr);
			System.out.println("--------------------------");
		}
	}

}
