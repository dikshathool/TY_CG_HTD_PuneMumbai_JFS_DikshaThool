package com.capgemini.Sorting;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeEmp {
	public static void main(String[] args) {
		TreeSet<Employee1> t=new TreeSet<Employee1>();
		Employee1 e1=new Employee1(1,"Diksha",45000);
		Employee1 e2=new Employee1(2,"Jaya",35000);
		Employee1 e3=new Employee1(3,"Rekha",32000);
		Employee1 e4=new Employee1(1,"Raima",55000);
		
		t.add(e1);
		t.add(e2);
		t.add(e3);
		t.add(e4);
		
		Iterator<Employee1> it=t.iterator();
		while(it.hasNext()) {
			Employee1 r=it.next();
			System.out.println("Id is: "+r.id);
			System.out.println("Name is: "+r.ename);
			System.out.println("Salary is: "+r.salary);
		}
		
		
		
	
	}

}
