package com.capgemini.Sorting;

public class Bank {
	int pin;
	String name;
	long micr;
	public Bank(int pin, String name, long micr) {
		this.pin = pin;
		this.name = name;
		this.micr = micr;
	}
	

}
