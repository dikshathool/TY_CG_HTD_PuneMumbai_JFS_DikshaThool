package com.capgemini.Sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		ArrayList<Student> al=new ArrayList<Student>();
		Student s1=new Student(1,"Diksha",78.34);
		Student s2=new Student(4,"Priya",65.34);
		Student s3=new Student(3,"Jaya",98.23);
		Student s4=new Student(2,"Krutika",50.45);
		
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		
		Collections.sort(al);
		
		Iterator<Student> it=al.iterator();
		while(it.hasNext())
		{
			Student s=it.next();
			System.out.println("Name is: "+s.name);
			System.out.println("Id is: "+s.id);
			System.out.println("Percentage is: "+s.percentage);
			System.out.println("--------------------------------");
			
		}

	}

}
