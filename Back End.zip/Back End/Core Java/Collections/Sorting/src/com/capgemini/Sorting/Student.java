package com.capgemini.Sorting;

public class Student implements Comparable<Student> {
	int id;
	String name;
	double percentage;
	public Student(int id, String name, double percentage) {
		this.id = id;
		this.name = name;
		this.percentage = percentage;
	}
	//Compare percentage using autoboxing
	@Override
	public int compareTo(Student s) {
		Double k=this.percentage;
		Double t=s.percentage;
		return k.compareTo(t);
	}
	
	
	//Logic to sort students by name
	/*
	 * @Override public int compareTo(Student s) { //return
	 * this.name.compareTo(s.name);//To sort in ascending order return
	 * this.name.compareTo(s.name) * -1;//To sort in descending order }
	 */
	
	//Logic to sort Students by percentage
	/* @Override 
	 * public int compareTo(Student s) { 
	 * if(this.percentage > s.percentage) { 
	 *     return 1; 
	 * } 
	 * else if(this.percentage < s.percentage)
	   { 
	       return -1; 
	   } 
	 * else { 
	 * return 0;
	 * } 
	 * }
	 */
	
	//Logic to sort student by Id
	/* @Override 
	 * public int compareTo(Student s) { 
	 * if(this.id > s.id) { 
	 * 	return 0;
	 * }else if(this.id < s.id) { 
	 * 	return -1; }
	 * else { 
	 * 	return 0; }
	 * 
	 * }
	 */
	
	
	
	
	
	

}
