package com.capgemini.CollectionFramework.list;

import java.util.ArrayList;

public class TestA {
	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		
		al.add(24);
		al.add("Chinnu");
		al.add(2.9);
		al.add('F');
		
		/*
		 * Object r=al.get(0); Object t=al.get(1); Object i=al.get(2); Object
		 * k=al.get(3);
		 * 
		 * System.out.println(r); System.out.println(t); System.out.println(i);
		 * System.out.println(k);
		 */
		int n=al.size();
		
		for(int i=0;i<n;i++)
		{
			Object r=al.get(i);
			System.out.println(r);
		}
		
	}

}
