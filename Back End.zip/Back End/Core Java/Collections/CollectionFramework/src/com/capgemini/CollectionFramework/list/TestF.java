package com.capgemini.CollectionFramework.list;

import java.util.ArrayList;

public class TestF {
	public static void main(String[] args) {
		ArrayList k=new ArrayList();
		k.add("Raj");
		k.add(19);
		k.add('M');
		k.add(6.14);
		
		for(Object r:k)
		{
			System.out.println(r);
		}
	}

}
