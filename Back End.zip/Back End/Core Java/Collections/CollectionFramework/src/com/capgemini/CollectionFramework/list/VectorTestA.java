package com.capgemini.CollectionFramework.list;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Vector;
public class VectorTestA {

	public static void main(String[] args) {
		Vector v=new Vector();
		v.add(9.6);
		v.add('M');
		v.add("Priya");
		v.add(2);

		System.out.println("*******for loop********");
		for(int i=0;i<4;i++)
		{
			Object r=v.get(i);
			System.out.println(r);
		}

		System.out.println("*******for each loop********");
		for(Object r:v)
		{
			System.out.println(r);
		}

		System.out.println("*******Iterator********");
		Iterator it=v.iterator();
		while(it.hasNext())
		{
			Object r=it.next();
			System.out.println(r);
		}

		System.out.println("*******ListIterator********");
		System.out.println("--------->Forward");
		ListIterator a= v.listIterator();
		while(a.hasNext())
		{
			Object r=a.next();
			System.out.println(r);
		}
		System.out.println("<--------------Backward");
		while(a.hasPrevious())
		{
			Object r=a.previous();
			System.out.println(r);
		}



	}

}

