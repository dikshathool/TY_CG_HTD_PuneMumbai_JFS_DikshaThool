package com.capgemini.CollectionFramework.list;

public class Student {
	

}
