package com.capgemini.CollectionFramework.list;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkTestB {

	public static void main(String[] args) {
		LinkedList<String> li=new LinkedList<String>();
		li.add("Diksha");
		li.add("John");
		li.add("Dimple");
		li.add("Maira");
		li.add("Raju");
		
		System.out.println("*******for loop********");
		for(int i=0;i<5;i++)
		{
			String r=li.get(i);
			System.out.println(r);
		}
		
		System.out.println("*******for each loop********");
		for(String r:li)
		{
			System.out.println(r);
		}
		
		System.out.println("*******Iterator********");
		Iterator<String> it=li.iterator();
		while(it.hasNext())
		{
			String r=it.next();
			System.out.println(r);
		}
		
		System.out.println("*******ListIterator********");
		System.out.println("--------->Forward");
	    ListIterator<String> a= li.listIterator();
		while(a.hasNext())
		{
			String r=a.next();
			System.out.println(r);
		}
		System.out.println("<--------------Backward");
		while(a.hasPrevious())
		{
			String r=a.previous();
			System.out.println(r);
		}
	

	}

}
