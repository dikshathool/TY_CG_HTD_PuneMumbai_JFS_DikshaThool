package com.capgemini.CollectionFramework.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class TestI {
	public static void main(String[] args) {
		ArrayList<Double> al=new ArrayList<Double>();
		al.add(2.4);
		al.add(9.6);
		al.add(4.1);
		al.add(3.2);
		
		Iterator<Double> it=al.iterator();
		while(it.hasNext())
		{
			Double r=it.next();
			System.out.println(r);
		}
		System.out.println("Forward--------->");
		ListIterator<Double> a=al.listIterator();
		while(a.hasNext())
		{
			Double r=a.next();
			System.out.println(r);
		}
		
		System.out.println("<--------Backward");
		
		while(a.hasPrevious())
		{
			Double r=a.previous();
			System.out.println(r);
		}
	}

}
