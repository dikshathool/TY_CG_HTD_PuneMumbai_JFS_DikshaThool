package com.capgemini.CollectionFramework.list;

public class Stud_test {

}
