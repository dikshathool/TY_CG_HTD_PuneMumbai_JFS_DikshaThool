package com.capgemini.CollectionFramework.list;

import java.util.ArrayList;
import java.util.Iterator;

public class StudTest {

	public static void main(String[] args) {
		ArrayList<Student> al=new ArrayList<Student>();
		
		Student s1=new Student(1,"Priya",26.56);
		Student s2=new Student(2,"Diksha",96.27);
		Student s3=new Student(3,"Raima",78.45);
		Student s4=new Student(4,"Jaya",56.04);
		Student s5=new Student(5,"Bhagya",70.56);
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		al.add(s5);
		
		System.out.println("******For loop********");
		for(int i=0;i<5;i++)
		{
			Student s=al.get(i);
			System.out.println("Id is: "+s.id);
			System.out.println("Name is: "+s.name);
			System.out.println("Percentage is: "+s.percentage);
			System.out.println("**********************************");
		}
		
		System.out.println("******For Each loop********");
		for(Student s:al)
		{
			System.out.println("Id is: "+s.id);
			System.out.println("Name is: "+s.name);
			System.out.println("Percentage is: "+s.percentage);
			System.out.println("**********************************");
		}
		
		System.out.println("******Iterator********");
		Iterator it=al.iterator();
		while(it.hasNext())
		{
			Student s=it.next();
			System.out.println("Id is: "+s.id);
			System.out.println("Name is: "+s.name);
			System.out.println("Percentage is: "+s.percentage);
			System.out.println("**********************************");
		}
		

	}

}
