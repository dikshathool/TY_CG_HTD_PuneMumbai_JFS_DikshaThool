package com.capgemini.CollectionFramework.list;

import java.util.ArrayList;

public class TestB {

	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		al.add(45);
		al.add("Diksha");
		al.add(70.20);
		al.add('D');
		al.add(true);
		
		for(Object k:al)
		{
			System.out.println(k);
		}
	}

}
