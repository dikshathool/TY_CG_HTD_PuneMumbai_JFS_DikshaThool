package com.capgemini.CollectionFramework.list;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class VectorTestB {

	public static void main(String[] args) {
		Vector<Character> v=new Vector<Character>();
		v.add('A');
		v.add('P');
		v.add('P');
		v.add('L');
		v.add('E');

		System.out.println("*******for loop********");
		for(int i=0;i<4;i++)
		{
			Character r=v.get(i);
			System.out.println(r);
		}

		System.out.println("*******for each loop********");
		for(Character r:v)
		{
			System.out.println(r);
		}

		System.out.println("*******Iterator********");
		Iterator<Character> it=v.iterator();
		while(it.hasNext())
		{
			Character r=it.next();
			System.out.println(r);
		}

		System.out.println("*******ListIterator********");
		System.out.println("--------->Forward");
		ListIterator<Character> a= v.listIterator();
		while(a.hasNext())
		{
			Character r=a.next();
			System.out.println(r);
		}
		System.out.println("<--------------Backward");
		while(a.hasPrevious())
		{
			Character r=a.previous();
			System.out.println(r);
		}



	}

}
