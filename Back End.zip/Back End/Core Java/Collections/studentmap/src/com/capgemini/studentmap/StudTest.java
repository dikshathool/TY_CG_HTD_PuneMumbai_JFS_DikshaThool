package com.capgemini.studentmap;

import java.util.ArrayList;

public class StudTest {
	public static void main(String[] args) {
		
		Student s1=new Student(1,"Ambika",76.5,'F');
		Student s2=new Student(2,"Ram",87.45,'M');
		Student s3=new Student(3,"Manish",67.34,'M');
		Student s4=new Student(4,"Maira",39.6,'F');
		Student s5=new Student(5,"Raaj",34.78,'M');
		Student s6=new Student(6,"Priya",98.50,'F');
		Student s7=new Student(7,"Gaurav",91.56,'M');
		Student s8=new Student(8,"Radha",41.67,'F');
		
		ArrayList<Student> al=new ArrayList<Student>();
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		al.add(s5);
		al.add(s6);
		al.add(s7);
		al.add(s8);
		
		//create helper object to call displayAll() method
		helper h=new helper();
		//h.displayAll(al);
		//h.displayPassed(al);
		//h.displayFailed(al);
		//h.displayPassedGender(al);
		//h.displayFailedGender(al);
		h.displayTopper(al);
		
		
		
		
	}

}
