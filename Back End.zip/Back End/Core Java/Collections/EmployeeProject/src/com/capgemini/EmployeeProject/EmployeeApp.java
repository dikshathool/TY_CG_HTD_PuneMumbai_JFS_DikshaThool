package com.capgemini.EmployeeProject;

import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeApp {
	int id;
	String ename;
	double salary;
	String job;
	
	ArrayList al=new ArrayList();
	Scanner sc=new Scanner(System.in);
	void addEmployee()
	{
		System.out.println("Enter Employee id: ");
		id=sc.nextInt();
		
		System.out.println("Enter Employee name: ");
		ename=sc.next();
		
		System.out.println("Enter Employee job: ");
		job=sc.next();
		
		System.out.println("Enter Employee salary: ");
		salary=sc.nextInt();
		
	}
	void displayEmployee()
	{
		System.out.println("Employee id is: "+id);
		System.out.println("Employee name is: "+ename);
		System.out.println("Employee job is: "+job);
		System.out.println("Employee salary is: "+salary);
	}
	
	

}
