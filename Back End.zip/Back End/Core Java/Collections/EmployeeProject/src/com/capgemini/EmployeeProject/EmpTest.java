package com.capgemini.EmployeeProject;

import java.util.Scanner;

public class EmpTest {

	public static void main(String[] args) {
		EmployeeApp e=new EmployeeApp();
		Scanner sc=new Scanner(System.in);
		
		while(true)
		{
			System.out.println("Enter required option: \n 1:Add Employe \n 2:Display employee \n 3:Exit");
			int opt=sc.nextInt();
			
			switch(opt)
			{
				case 1: e.addEmployee();
				break;
				
				case 2: e.displayEmployee();
				break;
				
				case 3: System.exit(0);
				break;
				
				default: System.out.println("Invalid option");
			}
		}
		

	}

}
