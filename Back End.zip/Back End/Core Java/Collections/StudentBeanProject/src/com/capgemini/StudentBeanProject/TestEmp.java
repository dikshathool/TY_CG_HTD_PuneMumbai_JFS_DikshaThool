package com.capgemini.StudentBeanProject;

import java.util.Iterator;
import java.util.TreeSet;

public class TestEmp {

	public static void main(String[] args) {
		ById comp=new ById();
		ByName comp1=new ByName();
		ByPercentage comp2=new ByPercentage();
		
		TreeSet<Student> ts=new TreeSet<Student>(comp2);
		Student s1=new Student();
		s1.setName("Diksha");
		s1.setId(1);
		s1.setPercentage(87.27);
		s1.setGender('F');
		
		Student s2=new Student();
		s2.setName("Raima");
		s2.setId(2);
		s2.setPercentage(55.67);
		s2.setGender('F');
		
		Student s3=new Student();
		s3.setName("Manish");
		s3.setId(3);
		s2.setPercentage(67.34);
		s2.setGender('M');
		
		Student s4=new Student();
		s4.setName("Rekha");
		s4.setId(4);
		s4.setPercentage(45.34);
		s4.setGender('F');
		
		Student s5=new Student();
		s5.setName("Raam");
		s5.setId(5);
		s5.setPercentage(98.45);
		s5.setGender('M');
		
		ts.add(s1);
		ts.add(s2);
		ts.add(s3);
		ts.add(s4);
		ts.add(s5);
		
		for(Student r: ts)
		{
			System.out.println("Name is: "+r.getName());
			System.out.println("Id is: "+r.getId());
			System.out.println("Percentage is: "+r.getPercentage());
			System.out.println("Gender is: "+r.getGender());
			System.out.println("-------------------------------");
		}
		/*
		 * Iterator<Student> it=ts.iterator(); while(it.hasNext()) { Student
		 * r=it.next(); System.out.println("Name is: "+r.getName());
		 * System.out.println("Id is: "+r.getId());
		 * System.out.println("Percentage is: "+r.getPercentage());
		 * System.out.println("Gender is: "+r.getGender());
		 * System.out.println("-------------------------------");
		 * 
		 * 
		 * }
		 */
		
		
		
		
		

	}

}
