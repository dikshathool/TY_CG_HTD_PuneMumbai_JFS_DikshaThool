package com.capgemini.java.currency;

public class ExceptionExample {
	

}
