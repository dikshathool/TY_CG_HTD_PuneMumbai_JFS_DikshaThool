package com.capgemini.java.currency;

import java.util.Currency;
import java.util.Set;

public class CurrencyExample {

	public static void main(String[] args) {
		//getInstance() method invoke on a name of the class(static)
		Currency currencyCode1=Currency.getInstance("INR");
		Currency currencyCode2=Currency.getInstance("USD");
		
		//getSymbol() method invoke on a object(non-static)
		String currencyCode1Symbol = currencyCode1.getSymbol();
		String currencyCode2Symbol = currencyCode2.getSymbol();
		
		System.out.println("Symbol for INR: "+currencyCode1Symbol);//Rs.
		System.out.println("Symbol for USD: "+currencyCode2Symbol);//USD
		System.out.println("*************************************");
		
		//getDisplayName() method invoke on a object
		String currencyCode1DisplayName = currencyCode1.getDisplayName();
		String currencyCode2DisplayName = currencyCode2.getDisplayName();
		System.out.println("Display Name for INR: "+currencyCode1DisplayName);//Indian Rupee
		System.out.println("Display Name for USD: "+currencyCode2DisplayName);//US Dollar
		System.out.println("*************************************");
		
		//getAvailableCurrencies() method invoke on a name of the class
		Set<Currency> currencies = Currency.getAvailableCurrencies();
		System.out.println(currencies);
		System.out.println("*************************************");
		
		//getDefaultFractionDigits() method invoke on a object
		int currencyCode1DefaultFraction = currencyCode1.getDefaultFractionDigits();
		int currencyCode2DefaultFraction = currencyCode2.getDefaultFractionDigits();
		System.out.println("Default Fraction Digit for INR: "+currencyCode1DefaultFraction);
		System.out.println("Default Fraction Digit for USD: "+currencyCode2DefaultFraction);
		System.out.println("*************************************");
	}

}


