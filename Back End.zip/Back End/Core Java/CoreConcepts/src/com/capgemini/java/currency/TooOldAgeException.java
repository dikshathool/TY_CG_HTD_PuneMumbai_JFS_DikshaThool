package com.capgemini.java.currency;

public class TooOldAgeException {

}
