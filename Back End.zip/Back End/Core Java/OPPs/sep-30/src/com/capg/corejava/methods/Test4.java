package com.capg.corejava.methods;

public class Test4 {

	public static void main(String[] args) {
		Facebook f=new Facebook();
		f.login(898346407, "diksha4");
		f.login("dikshat1@gmail.com", "diksha4");

	}

}
