package com.capg.corejava.hasA;

public class Fan {
	void on()
	{
		System.out.println("Fan ON");
	}
	void off()
	{
		System.out.println("Fan OFF");
	}

}
