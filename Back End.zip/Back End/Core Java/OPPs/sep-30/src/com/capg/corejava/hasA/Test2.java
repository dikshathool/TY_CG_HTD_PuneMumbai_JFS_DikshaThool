package com.capg.corejava.hasA;

public class Test2 {
	public static void main(String[] args) {
		//Car c=new Car();
		//c.m.play();
		//c.m.pause();
		//c.m.stop();
		Car.m.play();
		Car.m.pause();
		Car.m.stop();
	}

}
