package com.capg.corejava.methods;

public class Test3 {
	public static void main(String [] args)
	{
		Train t= new Train();
		t.search(5);
		t.search("Diksha");
	}

}
