package com.capg.corejava.hasA;

public class Music {

}
