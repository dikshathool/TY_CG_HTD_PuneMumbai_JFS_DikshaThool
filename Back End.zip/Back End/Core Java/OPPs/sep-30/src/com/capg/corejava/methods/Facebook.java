package com.capg.corejava.methods;

public class Facebook {
	void login(long phone, String password)
	{
		System.out.println("login using phone and password");
	}
	void login(String email, String password) {
		System.out.println("login using email and password");
	}
}
