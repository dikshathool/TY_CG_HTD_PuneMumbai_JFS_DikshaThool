package com.capg.corejava.hasA;

public class Marker {
	void write()
	{
		System.out.println("Marker use to write");
	}
	void color()
	{
		System.out.println("Marker color is black");
	}

}
