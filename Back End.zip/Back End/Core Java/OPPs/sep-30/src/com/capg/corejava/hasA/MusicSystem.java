package com.capg.corejava.hasA;

public class MusicSystem {
	void play()
	{
		System.out.println("Music System starts");
	}
	void pause()
	{
		System.out.println("Music System pause for sometimes");
	}
	void stop()
	{
		System.out.println("Stop Music system");
	}
}
