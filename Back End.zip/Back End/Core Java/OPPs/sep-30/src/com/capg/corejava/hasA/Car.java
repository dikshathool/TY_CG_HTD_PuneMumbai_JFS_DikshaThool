package com.capg.corejava.hasA;

public class Car {
	static MusicSystem m=new MusicSystem();//static 
	//MusicSystem m=new MusicSystem(); //non static


}
