package com.capg.corejava.methods;

public class Train {
	void search(String name)
	{
		System.out.println("Search by name");
	}
	void search(int num)
	{
		System.out.println("Search by number");
	}

}
