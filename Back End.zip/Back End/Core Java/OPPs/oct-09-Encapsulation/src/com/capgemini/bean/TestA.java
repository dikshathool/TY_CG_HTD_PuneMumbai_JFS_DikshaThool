package com.capgemini.bean;

public class TestA {

	public static void main(String[] args) {
		Student s=new Student();
		s.setId(20);
		s.setName("Diksha");
		s.setHeight(5.12);
		
		Database db=new Database();
		db.receive(s);
		System.out.println("*********************************");
		
		Employee g=new Employee();
		g.setId(10);
		g.setName("Raima");
		g.setSalary(45000);
		g.setRole("Developer");
		g.setDepartment("Software");
		db.receive(g);

	}

}
