package com.capgemini.bean;

public class TestB {

	public static void main(String[] args) {
		Car c= new Car(20,"benz");
		/*
		 * c.name="zen";
		 * c.setCost(400); //we cannot change value because variables declared as private
		 */
		System.out.println("Name is: "+c.getName());
		System.out.println("Cost is: "+c.getCost());
		System.out.println("**************************");
		
		Bus b=new Bus("Maira",3);
		System.out.println("Name is: "+b.getName());
		System.out.println("Seat is: "+b.getSeat());
	}

}
