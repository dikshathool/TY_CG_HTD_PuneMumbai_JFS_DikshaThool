package com.capg.array.genric;
//passing the array to a method using for each loop
public class Test8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		emp[] m=new emp[2];
		emp e1=new emp(1,"sham", 5678.80);
		emp e2=new emp(2,"raju", 7843.87);
		m[0]=e1;
		m[1]=e2;
		receive(m);

	}
	static void receive(emp[] a)
	{
		for(emp l:a)
		{
			System.out.println(l.id);
			System.out.println(l.name);
			System.out.println(l.sal);
			System.out.println(----------------);
		}
	}

}
