package com.capg.array.genric;

public class test3 {
	public static void main(String[] args)
	{
		double a[]= {12.3,34.5,23.6,7.3,45.2};
		for(double d:a)
		{
			System.out.println(d);
		}
	}

}
