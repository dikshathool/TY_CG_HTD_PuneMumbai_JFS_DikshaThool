package com.capg.array.genric;

public class test4 {
	public static void main(String[] args)
	{
		int[] a=new int[4];
		a[2]=100;
		for(int i:a)
		{
			System.out.println(i);
		}
	}

}
