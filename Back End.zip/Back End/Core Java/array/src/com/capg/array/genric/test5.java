package com.capg.array.genric;

public class test5 {
	public static void main(String [] args)
	{
		int[] m= {10,20,30,40};
		receive(m);
		double[] n= {10,20,30,40};
		receive1(n);
		String[] s= {"ram","sham","gyan","sheetal","jaya"};
		receive2(s);
		
		
	}
	static void receive(int[] a)
	{
		for(int i:a)
		{
			System.out.println(i);
		}
	}
	static void receive1(double[] n)
	{
		for(double j:n)
		{
			System.out.println(j);
		}
	}
	static void receive2(String[] s)
	{
		for(String k:s)
		{
			System.out.println(k);
		}
	}

}
