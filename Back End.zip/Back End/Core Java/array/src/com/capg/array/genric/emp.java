package com.capg.array.genric;

public class emp {
	int id;
	String name;
	double sal;
	public emp(int id, String name, double sal) {
		this.id = id;
		this.name = name;
		this.sal = sal;
	}
	

}
