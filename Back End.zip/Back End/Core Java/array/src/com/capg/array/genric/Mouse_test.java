package com.capg.array.genric;

public class Mouse_test {

	public static void main(String[] args) {
		Mouse m=new Mouse();
		double[] w= {23.4,54.7,50.9,30.8};
		int[] r= {4,5,8,2};
		
		m.walk(w);
		m.run(r);
		m.odd(r);
		
		
	}

}
