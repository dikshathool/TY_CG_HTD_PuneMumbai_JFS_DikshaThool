package com.capg.array.genric;

public class test2 {
	public static void main(String[] args)
	{
	int a[]= {10,9,15,3,6,22,1};
	for(int i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
	}
	}

}
