package com.capg.array.genric;

interface math
{
	int sqr(int i);
}

public class lambda_exp1 {

	public static void main(String[] args) {
		math j=i -> i*i;
		int k=j.sqr(34);
		System.out.println(k);

	}

}
