package com.capg.array.genric;

public class student {
	int id;
	String name;
	double percentage;
	public student(int id, String name, double percentage) {
		this.id = id;
		this.name = name;
		this.percentage = percentage;
	}
	

}
