package com.capg.array.genric;

public class test {
	public static void main(String [] args)
	{
		int[] a=new int[4];
		a[0]=10;
		a[1]=15;
		a[2]=6;
		a[3]=9;
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}

}
