package com.capg.array.genric;

public class Mouse {
	void odd(int[] b)
	{
		for(int h:b)
		{
			if(h%2!=0)
			{
			System.out.println(h);
			}
		}
	}
	void walk(double[] a)
	{
		//for each
		for(double s:a)
		{
			System.out.println(s);
		}
	}
	void run(int[] b)
	{
		//for loop
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		
	}

}
