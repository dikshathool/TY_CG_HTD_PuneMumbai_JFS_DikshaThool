package com.capg.array.genric;

interface call
{
	void gm();
}

public class lambda_exp3 {

	public static void main(String[] args) {
		call m=() -> System.out.println("Good Morning");
		m.gm();

	}

}
