package com.capg.array.genric;

import java.util.Scanner;

public class Scanner_input {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name: ");
		String i=sc.nextLine();
		
		System.out.println("Enter the age: ");
		int a=sc.nextInt();
		
		System.out.println("Enter the height: ");
		double h=sc.nextDouble();
		
		System.out.println("Name is "+i);
		System.out.println("Age is "+a);
		System.out.println("Height is "+h);
		
		sc.close();
		
	}

}
