package com.capg.array.genric;

interface circle
{
	double area(double r);
}

public class lambda_exp2 {

	public static void main(String[] args) {
		double pi=3.14;
		circle a= r -> pi*r*r;
		double k=a.area(2.4);
		System.out.println(k);

	}

}
