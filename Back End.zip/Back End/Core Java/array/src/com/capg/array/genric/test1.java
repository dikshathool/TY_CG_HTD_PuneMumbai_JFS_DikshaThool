package com.capg.array.genric;

public class test1 {
	public static void main(String [] args)
	{
		char ch[]= {'A','P','P','L','E'};
		for(char a:ch)
		{
			System.out.println(a);
		}
	}

}
