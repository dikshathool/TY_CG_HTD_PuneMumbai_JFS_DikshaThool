package com.capg.array.genric;

interface pi
{
	double find(double i);
}

public class lambda_exp5 {

	public static void main(String[] args) {
		pi f=i -> i;
	    double j=f.find(3.14);
	    System.out.println(j);

	}

}
