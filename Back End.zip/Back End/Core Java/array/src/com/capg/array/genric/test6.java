package com.capg.array.genric;

public class test6 {

	public static void main(String[] args) {
		student[] st=new student[4];
		student st1=new student(1,"Ram",87.27);
		student st2=new student(2,"sham",80.20);
		student st3=new student(3,"Chinu",50.72);
		student st4=new student(4,"Sheetal",60.80);
		
		st[0]=st1;
		st[1]=st2;
		st[2]=st3;
		st[3]=st4;
		receive(st);
	}
	static void receive(student[] arr)	
	{
		for(student s:arr)
		{
			System.out.println(s.id);
			System.out.println(s.name);
			System.out.println(s.percentage);
			System.out.println("---------------------");
			
		}
	}

}
