package com.capg.array.genric;

interface fact
{
	int find(int n);
}

public class lambda_exp4 {

	public static void main(String[] args) {
	fact f= n-> {	
			int fact=1;
		for(int i=1;i<=n;i++)
		{
		
			fact =fact*i;
		}
		return fact;

	};
	int i=f.find(6);
	System.out.println(i);
	}

}
