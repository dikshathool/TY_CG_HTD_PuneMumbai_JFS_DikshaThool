package com.capgemini.thread;

public class TestA {

	public static void main(String[] args) {
		System.out.println("Main started");
		
		Pen p=new Pen();
		//p.setDaemon(true);
		p.start();//start internally executes the thread
					//if we want thread effect then use start() 
					//if we use p.run() then it prints result one after other
		Pen t=new Pen();
		t.start();
		try {
			//Thread.sleep(1000);
			p.join();//main thread wait until the 'p' thread join
			t.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("Main ended");

	}

}
