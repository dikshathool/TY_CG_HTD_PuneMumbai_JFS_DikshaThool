

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestOneToMany {

	public static void main(String[] args) {
		PencileBox pencileBox=new PencileBox();
		pencileBox.setBoxid(4);
		pencileBox.setBname("Apsara");
		
		Pencile pencile=new Pencile();
		pencile.setPid(14);
		pencile.setColor("Black");
		pencile.setPencilebox(pencileBox);
		
		Pencile pencile1=new Pencile();
		pencile1.setPid(15);
		pencile1.setColor("Blue");
		pencile1.setPencilebox(pencileBox);
		
		EntityManagerFactory entityManagerFactory=null;
		EntityManager entityManager =null;
		EntityTransaction transaction = null;
		
		try {
			entityManagerFactory= Persistence.createEntityManagerFactory("TestPersistence");
			entityManager=entityManagerFactory.createEntityManager();
			transaction=entityManager.getTransaction();
			transaction.begin();
			 
			 entityManager.persist(pencile);
			 entityManager.persist(pencile1);
			 
			 
			System.out.println("Record Saved...");
			/*
			 * //For accessing details for voterCard from Person
			 * entityManager.persist(p);
			 */
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
			System.out.println("Do not enter duplicate key");
		}


	}

}
