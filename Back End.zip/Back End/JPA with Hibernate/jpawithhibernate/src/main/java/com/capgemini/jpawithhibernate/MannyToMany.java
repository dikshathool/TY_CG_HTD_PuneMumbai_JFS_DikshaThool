package com.capgemini.jpawithhibernate;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.manytomany.Course;
import com.capgemini.jpawithhibernate.manytomany.Student;

public class MannyToMany {
	public static void main(String[] args) {
		//ArrayList<Student> list1=new ArrayList<Student>();
		Course course=new Course();
		course.setCid(10);
		course.setCname("Java");
		
		Course course1=new Course();
		course1.setCid(11);
		course1.setCname("SQL");
		//course.setStudent(list1);
		
		ArrayList<Course> list=new ArrayList<Course>();
		list.add(course);
		list.add(course1);
		
		Student student=new Student();
		student.setId(1);
		student.setName("Bhagya");
		
		Student student1=new Student();
		student1.setId(2);
		student1.setName("Varun");
		//list1.add(student);
		//list1.add(student1);
		student.setCourse(list);
		
		EntityManagerFactory entityManagerFactory=null;
		EntityManager entityManager=null;
		EntityTransaction transaction=null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager=entityManagerFactory.createEntityManager();
			transaction=entityManager.getTransaction();
			transaction.begin();
			//entityManager.persist(student);
			Course course2=entityManager.find(Course.class, 10);
			course2.getStudent().get(0).getId();//It will start from zero index
			transaction.commit();
			
		}catch (Exception e) {
			
			e.printStackTrace();
			transaction.rollback();
			
		}
		entityManager.close();
	}

}
