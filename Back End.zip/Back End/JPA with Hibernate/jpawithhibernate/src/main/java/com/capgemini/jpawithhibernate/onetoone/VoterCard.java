package com.capgemini.jpawithhibernate.onetoone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="votercard")
public class VoterCard {
	@Column
	private int voter_id;
	@Id
	@Column
	private String address;
	//don't use cascade because it will get confuse 
	//here we are taking reference use in Person because voterCard is already mapped by Person class
	//bidirectional-> use mappedby
	@OneToOne(mappedBy="voterCard")
	private Person person;
	
	public int getVoter_id() {
		return voter_id;
	}
	public void setVoter_id(int voter_id) {
		this.voter_id = voter_id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	
	
	
	
}
