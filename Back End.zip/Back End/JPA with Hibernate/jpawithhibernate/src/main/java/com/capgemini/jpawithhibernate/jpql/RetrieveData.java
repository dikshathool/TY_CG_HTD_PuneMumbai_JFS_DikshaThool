package com.capgemini.jpawithhibernate.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernate.dto.Movie;

public class RetrieveData {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		String jpql = "From Movie";
		Query query =entityManager.createQuery(jpql);//helps to  create query object
		List<Movie> data=query.getResultList();
		
		for(Movie movie : data)
		{
			System.out.println(movie.getId());
			//System.out.println(movie.getName());
			//System.out.println(movie.getRating());
		}
		entityManager.close();

	}

}
