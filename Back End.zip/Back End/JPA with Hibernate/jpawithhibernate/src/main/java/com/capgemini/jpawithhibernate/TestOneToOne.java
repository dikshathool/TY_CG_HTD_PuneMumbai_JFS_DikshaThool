package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.onetoone.Person;
import com.capgemini.jpawithhibernate.onetoone.VoterCard;

public class TestOneToOne {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=null;
		EntityManager entityManager =null;
		EntityTransaction transaction = null;
		
		Person p=new Person();
		p.setPid(11);
		p.setName("Rahul");
		VoterCard vc=new VoterCard();
		vc.setVoter_id(23);
		vc.setAddress("Basavanagudi");
		p.setVoterCard(vc);
		
		try {
			entityManagerFactory= Persistence.createEntityManagerFactory("TestPersistence");
			entityManager=entityManagerFactory.createEntityManager();
			transaction=entityManager.getTransaction();
			transaction.begin();
			 
			  VoterCard cardDetail= entityManager.find(VoterCard.class,23);
			  cardDetail.getVoter_id(); 
			  cardDetail.getAddress();
			  cardDetail.getPerson().getPid(); 
			  cardDetail.getPerson().getName();
			 
			 
			System.out.println("Record Saved...");
			/*
			 * //For accessing details for voterCard from Person
			 * entityManager.persist(p);
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			//e.printStackTrace();
			System.out.println("Do not enter duplicate key");
		}

	}

}
