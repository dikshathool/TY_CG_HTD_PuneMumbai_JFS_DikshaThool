package com.capgemini.jpawithhibernatepractice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernatepractice.dto.Song;

public class Reference {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Song getData = entityManager.getReference(Song.class, 101);
		//System.out.println(getData.getClass());
		System.out.println("Id is: "+getData.getId()); 
		System.out.println("Name is: " + getData.getName()); 
		System.out.println("Rating is: " +getData.getArtist());
	}

}
