package com.capgemini.jpawithhibernatepractice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernatepractice.dto.Song;


public class Reattached {
	public static void main(String[] args) {
		EntityTransaction transaction = null;
		EntityManager entityManager =null;
		
		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager=entityManagerFactory.createEntityManager();
			transaction=entityManager.getTransaction();
			transaction.begin();
			Song song=entityManager.find(Song.class, 103);
			System.out.println(song.getId());
			System.out.println(entityManager.contains(song));
			entityManager.detach(song);
			//entityManager.clear();
			System.out.println(entityManager.contains(song));
			
			
			  //To merge detach object 
			Song song1=entityManager.merge(song);
			 song1.setName("Despacito"); 
			 transaction.commit();
			 			
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		entityManager.close();

	}

}
