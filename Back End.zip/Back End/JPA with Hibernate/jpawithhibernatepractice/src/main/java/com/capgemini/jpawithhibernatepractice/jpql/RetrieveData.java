package com.capgemini.jpawithhibernatepractice.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernatepractice.dto.Song;

public class RetrieveData {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		String jpql = "From Song";
		Query query =entityManager.createQuery(jpql);//helps to  create query object
		List<Song> data=query.getResultList();
		
		for(Song song : data)
		{
			System.out.println(song.getId());
			System.out.println(song.getName());
			System.out.println(song.getArtist());
		}
		entityManager.close();
	}

}
