package com.capgemini.jpawithhibernatepractice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernatepractice.dto.Song;

public class RetriveSong {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		Song data=entityManager.find(Song.class, 101);
		
		System.out.println("Song id is: "+data.getId());
		System.out.println("Song name is: "+data.getName());
		System.out.println("Artist is: "+data.getArtist());
		
		

	}

}
