package com.capg.jdbc;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class MyRetrival {
	public static void main(String[] args) {
		Connection conn=null;
		FileReader reader=null;
		Properties prop=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Statement stmt=null;
		
		try {
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded....");
			System.out.println("***************");
			
			reader = new FileReader("db.properties");
			prop=new Properties();
			prop.load(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		try {
			//Get the connection
			String dbUrl=prop.getProperty("dbUrl");
			conn=DriverManager.getConnection(dbUrl, prop.getProperty("user"),prop.getProperty("password"));
			System.out.println("Connection Established.......");
			System.out.println("*********************************");
			
			//Issue SQL query
			/*
			 * String query="SELECT * FROM users_info WHERE userid=?"; pstmt=
			 * conn.prepareStatement(query); System.out.println("Enter the User Id....");
			 * pstmt.setInt(1, sc.nextInt()); rs=pstmt.executeQuery();
			 */
			
			//Issue SQL query  via connection
			String query="SELECT * FROM users_info";
			stmt= conn.createStatement();
			rs= stmt.executeQuery(query);
			
			//Process the results returned by SQL query
			while(rs.next()) {
				System.out.println("User Id: "+rs.getInt(1)); //we can write index no or column name string 
				System.out.println("User Name: "+rs.getString("username"));
				System.out.println("Email: "+rs.getString(3));
				System.out.println("Password: "+rs.getString("password"));
				System.out.println("**************************");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
	}
		
		
	}

}
