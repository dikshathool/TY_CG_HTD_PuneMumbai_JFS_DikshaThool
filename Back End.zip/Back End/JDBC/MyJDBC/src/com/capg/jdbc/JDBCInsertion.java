package com.capg.jdbc;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class JDBCInsertion {

	public static void main(String[] args) {
		Connection conn=null;
		Statement stmt=null;
		try {
			//Load the driver 
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded....");
			System.out.println("*******************");
			
			//Get the connection
			String dbUrl="jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			conn=DriverManager.getConnection(dbUrl);
			System.out.println("Connection establish..");
			System.out.println("*******************");
			
			//Issue SQL query via connection
			String query="INSERT INTO users_info values(2019004,'Harshal Patil','hpatil798','patil30')";
			stmt=conn.createStatement();
			int count =	stmt.executeUpdate(query);
			//Process the Result
			if(count>0) {
			System.out.println("Data inserted.....");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt!=null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}		
	}

}

