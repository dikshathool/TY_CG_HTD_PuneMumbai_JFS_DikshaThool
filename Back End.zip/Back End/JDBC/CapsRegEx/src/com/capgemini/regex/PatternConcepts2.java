package com.capgemini.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts2 {
	public static void main(String[] args) {  
		Pattern pat = Pattern.compile("\\d");// represents any number between (0-9)
		Matcher mat = pat.matcher("1");
		System.out.println("Pattern for \\d:"+mat.matches());
		
		pat = Pattern.compile("\\d+");// represents any number
		mat = pat.matcher("100000");
		System.out.println("Pattern for \\d+:"+mat.matches());
		
		pat = Pattern.compile("\\D"); // represents anything but not numbers (single char)
		mat = pat.matcher("@");
		System.out.println("Pattern for \\D:"+mat.matches());
		
		pat = Pattern.compile("\\D+"); // represents anything but not numbers
		mat = pat.matcher("@qwerty $");
		System.out.println("Pattern for \\D+:"+mat.matches());
		
		pat = Pattern.compile("\\s"); // represents single space
		mat = pat.matcher(" ");
		System.out.println("Pattern for \\s:"+mat.matches());
		
		pat = Pattern.compile("\\s+"); // represents multiple spaces
		mat = pat.matcher("     ");
		System.out.println("Pattern for \\s+:"+mat.matches());
		
		pat = Pattern.compile("\\S"); // represents anything but not space(single char) 
		mat = pat.matcher("$");
		System.out.println("Pattern for \\S:"+mat.matches());
		
		pat = Pattern.compile("\\S+"); // represents anything but not spaces 
		mat = pat.matcher("vv");
		System.out.println("Pattern for \\S+:"+mat.matches());
		
		pat = Pattern.compile("\\w"); // represents single char 
		mat = pat.matcher("v");
		System.out.println("Pattern for \\w:"+mat.matches());
		
		pat = Pattern.compile("\\w+"); // represents multiple char 
		mat = pat.matcher("qwerty");
		System.out.println("Pattern for \\w+:"+mat.matches());
		
		pat = Pattern.compile("\\W"); // represents anything but not char (special char)
		mat = pat.matcher("!");
		System.out.println("Pattern for \\W:"+mat.matches());
		
		pat = Pattern.compile("\\W+"); // represents anything but not chars (special chars)
		mat = pat.matcher("!!$^#(");
		System.out.println("Pattern for \\W+:"+mat.matches());
		
		/*
		 * pat = Pattern.compile("\\w+ \\@ \\d+ \\w+ \\. \\w+"); 
		 * but not space(single char) mat = pat.matcher("dikshat@1234gmail.com");
		 * System.out.println("Pattern for \\S:"+mat.matches());
		 */
		}
}
