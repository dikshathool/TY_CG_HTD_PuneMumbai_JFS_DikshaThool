package com.capgemini.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts {

	public static void main(String[] args) {
		//Pattern class is final so cannot be inherited
		//compile method is used to create the object of the Pattern
		//Pattern pat = Pattern.compile("\\d"); //It is used for single digit("\\d")
		
		//Pattern pat = Pattern.compile("\\d+");//add + to get more than one digit
		
		//Pattern pat = Pattern.compile("\\d{10}");//to match 10 digits only
		
		Pattern pat = Pattern.compile("\\d{1,10}");//to match digits between 1 and 10
		
		//input is given by another class known as matcher
		//Matcher is a defualt class
		//object of matcher created by using matcher method
		Matcher mat=pat.matcher("1111111111");//it take input which need to be match
		
		//matches method used to match input and pattern
		System.out.println("For pattern \\d+: "+ mat.matches());
		
		
	}

}
//for single space ->small s
//for multiple space -> capital s
