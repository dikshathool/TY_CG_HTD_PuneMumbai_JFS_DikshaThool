package com.capgemini.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts1 {
	public static void main(String[] args) {
		//for single digit
		Pattern pat1= Pattern.compile("\\d");
		Matcher mat1= pat1.matcher("3");
		System.out.println("For pattern \\d: "+ mat1.matches());//true
		
		//for n number of digits
		Pattern pat2= Pattern.compile("\\d+");
		Matcher mat2= pat2.matcher("23451678");
		System.out.println("For pattern \\d+ : "+mat2.matches());//true
		
		//for number of digits between 1 and 10
		Pattern pat3=Pattern.compile("\\d{1,10}");
		Matcher mat3= pat3.matcher("3564899");
		System.out.println("For pattern \\d{1,10} :"+mat3.matches());//true
		
		//for 0 digits
		Pattern pat4= Pattern.compile("\\d{0}");
		Matcher mat4= pat4.matcher("");
		System.out.println("For pattern \\d{0} :"+mat4.matches());//true
		
		//for pattern between 1 and 9
		Pattern pat5=Pattern.compile("\\d{1,9}");
		Matcher mat5= pat5.matcher("");
		System.out.println("For pattern \\d{1,9} :"+mat5.matches());//false
		
		//for matching other than single digit(only single value)
		Pattern pat6=Pattern.compile("\\D");
		Matcher mat6=pat6.matcher("@");
		System.out.println("For pattern \\D :"+mat6.matches());
		
		//for matching other than multiple numbers(only multiple values)
		Pattern pat7=Pattern.compile("\\D+");
		Matcher mat7=pat7.matcher("hdjnaij");
		System.out.println("For pattern \\D+ :"+mat7.matches());
		
		Pattern pat8=Pattern.compile("\\D{1,10}");
		Matcher mat8=pat8.matcher("hkekk");
		System.out.println("For pattern \\D{1,10} :"+mat8.matches());
		
		//for single space ->small s
		//represents anything but not space(single char) -> capital s
		
		pat1=Pattern.compile("\\s");
		mat1=pat1.matcher(" ");
		System.out.println("For Pattern \\s: "+mat1.matches());
		
		pat1=Pattern.compile("\\S");
		mat1=pat1.matcher("r");
		System.out.println("For Pattern \\S: "+mat1.matches());
	}

}
