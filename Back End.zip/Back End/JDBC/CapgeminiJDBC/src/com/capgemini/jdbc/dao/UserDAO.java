package com.capgemini.jdbc.dao;

//import java.util.List;

import com.capgemini.jdbc.beans.UserBean;

public interface UserDAO {
	//to declare abstract method
	
	//public List<UserBean> getAllInfo();
	public UserBean getInfo(int userid);
	
}
