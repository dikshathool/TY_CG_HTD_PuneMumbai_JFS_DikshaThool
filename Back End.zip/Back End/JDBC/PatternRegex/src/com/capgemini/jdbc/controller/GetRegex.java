package com.capgemini.jdbc.controller;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jdbc.beans.UserBean;
import com.capgemini.jdbc.dao.UserDAO;
import com.capgemini.jdbc.factory.UserFactory;

public class GetRegex {

		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			UserDAO dao=UserFactory.getInstance();
			System.out.println("Enter username: ");
			String name=sc.nextLine();
			UserBean user=dao.getregex(name);
			
			Pattern pat1 = Pattern.compile("\\w+\\s\\w+");
			Matcher mat1 = pat1.matcher(name);
			System.out.println(mat1.matches());
			boolean b1=mat1.matches();
			
			
		/*
		 * Pattern pat2 = Pattern.compile("\\w+\\@\\w+\\.\\w+"); // for email id's.
		 * Matcher mat2 = pat2.matcher(name); System.out.println(mat2.matches());
		 * boolean b2=mat2.matches(); UserBean user=dao.getregex(name);
		 */if(b1==true)
		 {
			if(user!=null)
			{
				System.out.println(user);
				
			}else {
				System.out.println("Something went wrong...");
			}
		 }else {
			 System.out.println("Wrong");
		 }
		/*
		 * if(b1==true) { System.out.println(user); }else {
		 * System.out.println("Please enter name in correct manner..."); }
		 */
			
			sc.close();
			
		/*
		 * pat = Pattern.compile("\\w+\\s\\w+\\s\\w+"); // for first, middle, and last
		 * name mat = pat.matcher("A B C"); System.out.println(mat.matches());
		 * 
		 * pat = Pattern.compile("[A-Za-z]{1,25}\\s[A-Za-z]{1,25}"); //for names with
		 * limited chars mat = pat.matcher("Ivan Shishkin");
		 * System.out.println(mat.matches());
		 * 
		 * pat = Pattern.compile("\\w+\\W+\\w+"); //for alphanumeric passwords mat =
		 * pat.matcher("afimf#4df"); System.out.println(mat.matches());
		 */

		}
}
	
