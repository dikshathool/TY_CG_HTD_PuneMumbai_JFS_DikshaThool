package com.capgemini.application.factory;

public class UserFactory {

}
