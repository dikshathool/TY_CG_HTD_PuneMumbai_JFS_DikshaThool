package com.capgemini.application.dao;

public interface UserDAO {

}
