package com.capgemini.application.controller;

public class GetInfo {

	public static void main(String[] args) {
		

	}

}
