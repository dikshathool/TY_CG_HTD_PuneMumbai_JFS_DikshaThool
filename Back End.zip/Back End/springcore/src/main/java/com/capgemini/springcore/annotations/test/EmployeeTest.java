package com.capgemini.springcore.annotations.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.capgemini.springcore.annotations.beans.DepartmentBean;
import com.capgemini.springcore.annotations.beans.EmployeeBean;
import com.capgemini.springcore.annotations.config.DepartmentConfig;
import com.capgemini.springcore.annotations.config.EmployeeConfig;

public class EmployeeTest {

	public static void main(String[] args) {
		//get annotation context from EmployeeConfig
		ApplicationContext context = new AnnotationConfigApplicationContext(EmployeeConfig.class);
		//close container 
		((AbstractApplicationContext)context).registerShutdownHook();
		//get bean from EmployeeBean
		EmployeeBean employeeBean = context.getBean(EmployeeBean.class);
		System.out.println("EMPLOYEE INFO:");
		System.out.println("Employee ID = "+employeeBean.getEmpId());
		System.out.println("Employee Name = "+employeeBean.getEmpName());
		System.out.println();
		System.out.println("DEPARTMENT INFO:");
		System.out.println("Department ID = "+employeeBean.getDeptBean().getDeptId());
		System.out.println("Department Name = "+employeeBean.getDeptBean().getDeptName());
		
		//((AbstractApplicationContext)context).close();
	}

}
