package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MobileBean;

public class MobileTest {

	public static void main(String[] args) {
		//create container
		ApplicationContext context = new ClassPathXmlApplicationContext("mobileConfig.xml");
		
		//get mobileBean object from xml file
		MobileBean mobileBean = context.getBean("mobile", MobileBean.class);
		
		//print data
		System.out.println("Mobile Brand Name = "+mobileBean.getBrandName());
		System.out.println("Mobile Model Name = "+mobileBean.getModelName());
		System.out.println("Mobile Display Size = "+mobileBean.getMobileDisplay().getDisplaySize());
		System.out.println("Mobile Display Resolution = "+mobileBean.getMobileDisplay().getResolution());
	}

}
