package com.capgemini.springcore.beans;

public class MobileDisplayBean {
	private int displaySize;
	private double resolution;
	public int getDisplaySize() {
		return displaySize;
	}
	public void setDisplaySize(int displaySize) {
		this.displaySize = displaySize;
	}
	public double getResolution() {
		return resolution;
	}
	public void setResolution(double resolution) {
		this.resolution = resolution;
	}
	
}
