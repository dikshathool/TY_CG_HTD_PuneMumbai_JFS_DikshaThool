package com.capgemini.springcore.annotations.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.springcore.annotations.beans.DepartmentBean;

@Configuration
public class DepartmentConfig {
	@Bean(name = "dev")
	public DepartmentBean getDevDept() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(001);
		bean.setDeptName("Developers");
		return bean;
	}//End of getDevDept()
	@Bean(name = "testing")
	public DepartmentBean getTestingDept() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(002);
		bean.setDeptName("Testing");
		return bean;
	}//End of getTestingDept()
	@Bean(name = "hr")
	//commented primary annotation because instead of this we used Qalifire(name="testing") in EmployeeBean class
	//@Primary
	public DepartmentBean getHrDept() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(003);
		bean.setDeptName("HR");
		return bean;
	}//End of getHrDept()
}//End of class
