package com.capgemini.springcore.annotations.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.capgemini.springcore.annotations.beans.ISuzu;
import com.capgemini.springcore.annotations.beans.VolsWagon;
import com.capgemini.springcore.interfaces.Engine;

@Configuration
public class EngineConfig {
	
	@Bean(name = "iSuzu")
	@Primary
	public Engine getISuzu() {
		return new ISuzu();
	}
	@Bean(name = "vw")
	public Engine getVolsWagon() {
		return new VolsWagon();
	}

}
