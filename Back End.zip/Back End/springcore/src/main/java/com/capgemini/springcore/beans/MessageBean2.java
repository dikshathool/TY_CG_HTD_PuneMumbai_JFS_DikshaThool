package com.capgemini.springcore.beans;

import java.lang.reflect.Constructor;

public class MessageBean2 {
	private String message;
	
	public MessageBean2() {
		System.out.println("Constructor executed...");
	}
	// Getter and Setter
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public void init() {
		System.out.println("Its init phase...");
	}
	public void destroy() {
		System.out.println("Its Destroy Phase!");
	}
}
