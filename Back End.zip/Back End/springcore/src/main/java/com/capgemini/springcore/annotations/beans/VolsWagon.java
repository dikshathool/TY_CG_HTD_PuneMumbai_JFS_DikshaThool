package com.capgemini.springcore.annotations.beans;

import com.capgemini.springcore.interfaces.Engine;

public class VolsWagon implements Engine {

	@Override
	public int getCC() {
		return 1300;
	}

	@Override
	public String getType() {
		return "VW: 4-Stroke Diesel";
	}

}
