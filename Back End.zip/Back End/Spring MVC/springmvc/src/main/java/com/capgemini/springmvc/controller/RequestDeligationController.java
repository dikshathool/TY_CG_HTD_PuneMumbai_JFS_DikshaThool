package com.capgemini.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RequestDeligationController {
	//handler method
	@GetMapping("/redirect")
	public String redirectRequest() {
		
		return "redirect:http://www.facebook.com";
	}//End of redirectRequest
	
	//forward we can in jsp but always used include in jsp
	@GetMapping("/forward")
	public String forwardRequest() {
		
		return "forward:/loginForm";
	}//End of forwardRequest()
	
}//End of Class
