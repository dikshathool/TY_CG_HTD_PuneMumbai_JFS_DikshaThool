package com.capgemini.springmvc.beans;

public class UserBean {
	private int empId;
	private String password;
	
	//Getters and Setters
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}//End of class
