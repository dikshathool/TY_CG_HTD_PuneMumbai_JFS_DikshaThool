package com.capgemini.springboot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
//we can use @Component and @Repository but preffered @Configuration because it is an configurtion class
@Configuration
public class EmployeeConfig {
	@Bean
	public LocalEntityManagerFactoryBean getEMF() {
		LocalEntityManagerFactoryBean factoryBean = new LocalEntityManagerFactoryBean();
		factoryBean.setPersistenceUnitName("employeePersistenceUnit");
		
		return factoryBean;
	}//End of getEMF()
}//End of class
