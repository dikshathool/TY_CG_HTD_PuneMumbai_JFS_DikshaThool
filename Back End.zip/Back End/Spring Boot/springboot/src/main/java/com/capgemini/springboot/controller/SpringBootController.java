package com.capgemini.springboot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
//To handle request, create controller
@RestController
public class SpringBootController {
	//To handle request, create handler method
	
	@GetMapping(path = "/hello", produces = "text/plain")//it is going to produce text/plain on browser
	public String welcomeMessage() {
		return "Welcome to SpringBoot!";
	}//End of welcomeMessage()
}//End of SpringBootController
